/**
 * SIMRS RS Rakyat Sejahterah
 * Data Layer — localStorage-based CRUD
 */

const DB = {
  PREFIX: 'simrs_',

  get(collection) {
    try {
      return JSON.parse(localStorage.getItem(this.PREFIX + collection)) || [];
    } catch { return []; }
  },

  set(collection, data) {
    localStorage.setItem(this.PREFIX + collection, JSON.stringify(data));
  },

  getOne(collection, id) {
    return this.get(collection).find(item => String(item.id) === String(id)) || null;
  },

  insert(collection, item) {
    const data = this.get(collection);
    item.id = item.id || (Date.now() + Math.random()).toString(36).toUpperCase().slice(0, 8);
    item.createdAt = item.createdAt || new Date().toISOString();
    data.push(item);
    this.set(collection, data);
    return item;
  },

  update(collection, id, updates) {
    const data = this.get(collection);
    const idx = data.findIndex(item => String(item.id) === String(id));
    if (idx === -1) return null;
    data[idx] = { ...data[idx], ...updates, updatedAt: new Date().toISOString() };
    this.set(collection, data);
    return data[idx];
  },

  delete(collection, id) {
    const data = this.get(collection);
    const filtered = data.filter(item => String(item.id) !== String(id));
    this.set(collection, filtered);
    return filtered.length < data.length;
  },

  findBy(collection, field, value) {
    return this.get(collection).filter(item => String(item[field]) === String(value));
  },

  findOneBy(collection, field, value) {
    return this.get(collection).find(item => String(item[field]) === String(value)) || null;
  },

  search(collection, query, fields) {
    if (!query || !query.trim()) return this.get(collection);
    const q = query.toLowerCase().trim();
    return this.get(collection).filter(item =>
      fields.some(f => String(item[f] || '').toLowerCase().includes(q))
    );
  },

  count(collection) {
    return this.get(collection).length;
  },

  countBy(collection, field, value) {
    return this.get(collection).filter(item => String(item[field]) === String(value)).length;
  },

  exists(collection, id) {
    return this.get(collection).some(item => String(item.id) === String(id));
  },

  clear(collection) {
    this.set(collection, []);
  },

  // Helper: next queue number for today
  nextQueueNumber(doctorId, date) {
    const todayQueues = this.get('queues').filter(q => q.doctorId === doctorId && q.date === date);
    return todayQueues.length + 1;
  },

  // Helper: get today's visits
  todayVisits() {
    const today = new Date().toISOString().split('T')[0];
    return this.get('visits').filter(v => v.date === today);
  },

  // Helper: get visits by patient
  patientVisits(patientId) {
    return this.get('visits').filter(v => v.patientId === patientId).sort((a, b) => new Date(b.date) - new Date(a.date));
  },

  // Helper: get EMR for visit
  visitEMR(visitId) {
    return this.get('emr').find(e => String(e.visitId) === String(visitId)) || null;
  },

  // Helper: get prescriptions for EMR
  emrPrescriptions(emrId) {
    return this.get('prescriptions').filter(p => String(p.emrId) === String(emrId));
  },

  // Helper: get payment for visit
  visitPayment(visitId) {
    return this.get('payments').find(p => String(p.visitId) === String(visitId)) || null;
  },

  // Helper: get lab orders for visit
  visitLabOrders(visitId) {
    return this.get('labOrders').filter(l => String(l.visitId) === String(visitId));
  }
};
