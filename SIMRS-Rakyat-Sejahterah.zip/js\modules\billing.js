/**
 * SIMRS — Billing Module
 */
Modules.Billing = {
  searchQuery: '',
  filterStatus: '',

  render(container) {
    const payments = DB.get('payments');
    const filtered = payments.filter(p => {
      const visit = DB.getOne('visits', p.visitId);
      const pat = visit ? DB.getOne('patients', visit.patientId) : null;
      const q = this.searchQuery.toLowerCase();
      const matchSearch = !q || (pat?.name||'').toLowerCase().includes(q) || p.id.toLowerCase().includes(q);
      const matchStatus = !this.filterStatus || p.status === this.filterStatus;
      return matchSearch && matchStatus;
    }).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));

    const totalRevenue = payments.filter(p=>p.status==='lunas').reduce((s,p)=>s+(p.total||0),0);
    const unpaid = payments.filter(p=>p.status==='belum_bayar').length;

    container.innerHTML = `
      <div class="page-header fade-up">
        <div>
          <h2>Billing & Pembayaran</h2>
          <p>Total pendapatan: ${App.fmt.currency(totalRevenue)}</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary" onclick="Modules.Billing.showCreateBilling()">
            ${App.icon('plus',14)} Buat Tagihan
          </button>
        </div>
      </div>

      ${unpaid > 0 ? `
      <div class="alert alert-warning mb-4">
        ${App.icon('alert-circle',15)} <strong>${unpaid} tagihan</strong> belum dibayar. Segera proses pembayaran.
      </div>` : ''}

      <!-- Stats -->
      <div class="stats-grid stagger mb-4">
        <div class="stat-card fade-up">
          <div class="stat-icon" style="background:var(--success-subtle)">${App.icon('check-circle',24,'','color:var(--success)')}</div>
          <div class="stat-body"><h3>${App.fmt.currency(totalRevenue)}</h3><p>Total Pendapatan</p></div>
        </div>
        <div class="stat-card fade-up">
          <div class="stat-icon" style="background:var(--primary-subtle)">${App.icon('receipt',24,'','color:var(--primary)')}</div>
          <div class="stat-body"><h3>${payments.filter(p=>p.status==='lunas').length}</h3><p>Transaksi Lunas</p></div>
        </div>
        <div class="stat-card fade-up">
          <div class="stat-icon" style="background:var(--danger-subtle)">${App.icon('alert-circle',24,'','color:var(--danger)')}</div>
          <div class="stat-body"><h3>${unpaid}</h3><p>Belum Dibayar</p></div>
        </div>
        <div class="stat-card fade-up">
          <div class="stat-icon" style="background:var(--info-subtle)">${App.icon('trending-up',24,'','color:var(--info)')}</div>
          <div class="stat-body">
            <h3>${App.fmt.currency(payments.filter(p=>p.status==='lunas'&&p.createdAt?.startsWith(new Date().toISOString().split('T')[0])).reduce((s,p)=>s+(p.total||0),0))}</h3>
            <p>Pendapatan Hari Ini</p>
          </div>
        </div>
      </div>

      <div class="card fade-up">
        <div class="card-header">
          <div class="flex gap-2 flex-1">
            <div class="search-bar" style="max-width:240px;flex:1">
              ${App.icon('search',15,'search-icon')}
              <input type="text" placeholder="Cari tagihan / nama pasien..." value="${this.searchQuery}"
                oninput="Modules.Billing.searchQuery=this.value;Modules.Billing.render(document.getElementById('content-area'))" />
            </div>
            <select class="form-control" style="width:150px;font-size:12px" onchange="Modules.Billing.filterStatus=this.value;Modules.Billing.render(document.getElementById('content-area'))">
              <option value="">Semua Status</option>
              <option value="lunas" ${this.filterStatus==='lunas'?'selected':''}>Lunas</option>
              <option value="belum_bayar" ${this.filterStatus==='belum_bayar'?'selected':''}>Belum Bayar</option>
            </select>
          </div>
          <span style="font-size:12px;color:var(--text-muted)">${filtered.length} tagihan</span>
        </div>

        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead>
              <tr><th>ID</th><th>Pasien</th><th>Tgl. Kunjungan</th><th>Total</th><th>Metode</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
              ${filtered.length === 0 ? `<tr><td colspan="7"><div class="empty-state">${App.icon('receipt',40,'','color:var(--text-placeholder)')}<h4>Belum ada tagihan</h4></div></td></tr>` :
              filtered.map(p => {
                const visit = DB.getOne('visits', p.visitId);
                const pat = visit ? DB.getOne('patients', visit.patientId) : null;
                return `
                  <tr>
                    <td><code style="font-size:11px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${p.id}</code></td>
                    <td>
                      <div class="flex items-center gap-2">
                        <div class="avatar avatar-sm avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
                        <div class="font-semibold" style="font-size:13px">${pat?.name||'—'}</div>
                      </div>
                    </td>
                    <td style="font-size:12px;white-space:nowrap">${App.fmt.dateShort(visit?.date)}</td>
                    <td style="font-weight:700;font-size:13px">${App.fmt.currency(p.total)}</td>
                    <td>
                      <span class="badge ${p.method==='BPJS'?'badge-success':p.method==='Mandiri'||p.method==='Tunai'?'badge-primary':'badge-info'}">
                        ${p.method}
                      </span>
                    </td>
                    <td>${App.statusBadge(p.status)}</td>
                    <td>
                      <div class="flex gap-1">
                        <button class="btn btn-xs btn-outline-primary" onclick="Modules.Billing.showDetail('${p.id}')">${App.icon('eye',12)} Detail</button>
                        ${p.status === 'belum_bayar' ? `<button class="btn btn-xs btn-success" onclick="Modules.Billing.processPayment('${p.id}')">${App.icon('credit-card',12)} Bayar</button>` : ''}
                        <button class="btn btn-xs btn-secondary" onclick="Modules.Billing.printReceipt('${p.id}')">${App.icon('printer',12)}</button>
                      </div>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  showCreateBilling() {
    // Get visits without payment
    const allVisits = DB.get('visits').filter(v => v.status === 'selesai');
    const paidVisits = DB.get('payments').map(p => p.visitId);
    const unbilledVisits = allVisits.filter(v => !paidVisits.includes(v.id));

    if (unbilledVisits.length === 0) {
      App.toast('Tidak ada kunjungan yang perlu ditagih', 'info');
      return;
    }

    App.modal({
      title: 'Buat Tagihan',
      subtitle: 'Pilih kunjungan pasien',
      body: `
        <div style="display:flex;flex-direction:column;gap:8px">
          ${unbilledVisits.map(v => {
            const pat = DB.getOne('patients', v.patientId);
            const doc = DB.getOne('doctors', v.doctorId);
            return `
              <div class="rx-item" style="cursor:pointer" onclick="App.closeModal();setTimeout(()=>Modules.Billing.showBillingForm('${v.id}'),200)">
                <div>
                  <div class="font-semibold">${pat?.name||'—'}</div>
                  <div class="text-sm text-muted-color">${doc?.name?.split(',')[0]||''} · ${App.fmt.dateShort(v.date)}</div>
                </div>
                ${App.icon('arrow-right',16,'','color:var(--primary)')}
              </div>`;
          }).join('')}
        </div>
      `
    });
  },

  showBillingForm(visitId) {
    const visit = DB.getOne('visits', visitId);
    const pat = DB.getOne('patients', visit?.patientId);
    const doc = DB.getOne('doctors', visit?.doctorId);
    const emr = DB.visitEMR(visitId);
    const rxList = emr ? DB.emrPrescriptions(emr.id) : [];
    const labOrders = DB.visitLabOrders(visitId);

    // Build items
    const items = [];
    items.push({ name: `Biaya Konsultasi — ${doc?.name||'Dokter'}`, qty: 1, price: doc?.consultationFee||100000 });
    rxList.forEach(rx => {
      rx.medications?.forEach(m => {
        const med = DB.getOne('medications', m.medicationId);
        if (med) items.push({ name: `${m.name} (${m.qty} ${m.unit})`, qty: 1, price: med.price * m.qty });
      });
    });
    labOrders.forEach(lo => {
      lo.tests?.forEach(t => items.push({ name: `Pemeriksaan ${t.name}`, qty: 1, price: 50000 }));
    });

    const subtotal = items.reduce((s,i) => s + i.price, 0);

    App.modal({
      title: 'Rincian Tagihan',
      subtitle: `${pat?.name||''} — ${App.fmt.dateShort(visit?.date)}`,
      size: 'modal-lg',
      body: `
        <div class="flex gap-3 items-center p-3 mb-4" style="background:#f8fafc;border-radius:var(--radius-sm);border:1px solid var(--border)">
          <div class="avatar avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
          <div>
            <div class="font-bold">${pat?.name||'—'}</div>
            <div style="font-size:12px;color:var(--text-muted)">${pat?.id} · ${pat?.insurance||'Mandiri'} ${pat?.insuranceNo?'#'+pat.insuranceNo:''}</div>
          </div>
        </div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:16px;font-size:13px">
          <thead>
            <tr style="border-bottom:2px solid var(--border)">
              <th style="padding:8px 0;text-align:left;font-size:11px;color:var(--text-muted)">ITEM</th>
              <th style="padding:8px 0;text-align:right;font-size:11px;color:var(--text-muted)">JUMLAH</th>
            </tr>
          </thead>
          <tbody id="billing-items">
            ${items.map(i => `
              <tr style="border-bottom:1px solid #f1f5f9">
                <td style="padding:8px 0">${i.name}</td>
                <td style="padding:8px 0;text-align:right;font-weight:600">${App.fmt.currency(i.price)}</td>
              </tr>`).join('')}
          </tbody>
          <tfoot>
            <tr style="border-top:2px solid var(--border)">
              <td style="padding:10px 0;font-weight:700">Subtotal</td>
              <td style="padding:10px 0;text-align:right;font-weight:700">${App.fmt.currency(subtotal)}</td>
            </tr>
          </tfoot>
        </table>

        <div class="form-grid" style="gap:12px">
          <div class="form-group" style="margin:0">
            <label class="form-label">Metode Pembayaran</label>
            <select class="form-control" id="payMethod" onchange="Modules.Billing._updatePayForm()">
              <option value="Tunai">Tunai</option>
              <option value="BPJS" ${pat?.insurance==='BPJS'?'selected':''}>BPJS Kesehatan</option>
              <option value="Asuransi" ${pat?.insurance&&pat.insurance!=='BPJS'?'selected':''}>Asuransi</option>
              <option value="Debit/Kartu">Debit / Kartu Kredit</option>
            </select>
          </div>
          <div class="form-group" style="margin:0" id="insuranceField" style="${pat?.insurance?'':'display:none'}">
            <label class="form-label">No. Kartu Asuransi</label>
            <input class="form-control" id="payInsuranceNo" value="${pat?.insuranceNo||''}" placeholder="Nomor kartu" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Diskon (Rp)</label>
            <input type="number" class="form-control" id="payDiscount" value="0" min="0" oninput="Modules.Billing._calcTotal(${subtotal})" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Biaya Admin (Rp)</label>
            <input type="number" class="form-control" id="payAdminFee" value="15000" min="0" oninput="Modules.Billing._calcTotal(${subtotal})" />
          </div>
        </div>

        <div style="background:var(--primary-subtle);border:1px solid var(--primary-border);border-radius:var(--radius-sm);padding:14px;margin-top:12px">
          <div class="flex justify-between" style="font-size:14px;font-weight:800">
            <span>TOTAL BAYAR</span>
            <span id="totalDisplay" style="color:var(--primary)">${App.fmt.currency(subtotal + 15000)}</span>
          </div>
        </div>

        <input type="hidden" id="billingSubtotal" value="${subtotal}" />
        <input type="hidden" id="billingItems" value='${JSON.stringify(items).replace(/'/g,"&#39;")}' />
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-primary" onclick="Modules.Billing.saveBilling('${visitId}')">
          ${App.icon('credit-card',14)} Simpan & Proses Bayar
        </button>
      `
    });
  },

  _calcTotal(subtotal) {
    const discount = parseInt(document.getElementById('payDiscount')?.value||0);
    const admin = parseInt(document.getElementById('payAdminFee')?.value||0);
    const total = subtotal - discount + admin;
    const el = document.getElementById('totalDisplay');
    if (el) el.textContent = App.fmt.currency(Math.max(0, total));
  },

  _updatePayForm() {
    const method = document.getElementById('payMethod')?.value;
    const insField = document.getElementById('insuranceField');
    if (insField) insField.style.display = (method === 'BPJS' || method === 'Asuransi') ? '' : 'none';
  },

  saveBilling(visitId) {
    const subtotal = parseInt(document.getElementById('billingSubtotal')?.value||0);
    const discount = parseInt(document.getElementById('payDiscount')?.value||0);
    const adminFee = parseInt(document.getElementById('payAdminFee')?.value||0);
    const method = document.getElementById('payMethod')?.value;
    const insuranceNo = document.getElementById('payInsuranceNo')?.value||'';
    const items = JSON.parse(document.getElementById('billingItems')?.value||'[]');
    const total = subtotal - discount + adminFee;

    const payId = 'PAY' + Date.now().toString().slice(-6);
    DB.insert('payments', {
      id: payId,
      visitId,
      items,
      subtotal,
      discount,
      adminFee,
      total: Math.max(0, total),
      method,
      insuranceNo,
      insuranceCover: method !== 'Tunai' && method !== 'Debit/Kartu' ? total : 0,
      patientPay: method !== 'Tunai' && method !== 'Debit/Kartu' ? adminFee : total,
      status: 'lunas',
      paidAt: new Date().toISOString(),
      paidBy: App.user.id,
      notes: '',
    });

    App.toast(`Tagihan ${payId} berhasil diproses — ${App.fmt.currency(Math.max(0,total))}`, 'success');
    App.closeModal();
    this.render(document.getElementById('content-area'));
  },

  processPayment(payId) {
    DB.update('payments', payId, { status: 'lunas', paidAt: new Date().toISOString(), paidBy: App.user.id });
    App.toast('Pembayaran berhasil diproses', 'success');
    this.render(document.getElementById('content-area'));
  },

  showDetail(payId) {
    const p = DB.getOne('payments', payId);
    if (!p) return;
    const visit = DB.getOne('visits', p.visitId);
    const pat = visit ? DB.getOne('patients', visit.patientId) : null;
    const doc = visit ? DB.getOne('doctors', visit.doctorId) : null;

    App.modal({
      title: `Tagihan #${p.id}`,
      subtitle: `${pat?.name||''} — ${App.fmt.dateShort(visit?.date)}`,
      size: 'modal-lg',
      body: `
        <div class="flex gap-3 items-center p-3 mb-4" style="background:#f8fafc;border-radius:var(--radius-sm);border:1px solid var(--border)">
          <div class="avatar avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
          <div class="flex-1">
            <div class="font-bold">${pat?.name||'—'}</div>
            <div style="font-size:12px;color:var(--text-muted)">${pat?.id} · ${doc?.name?.split(',')[0]||''}</div>
          </div>
          ${App.statusBadge(p.status)}
        </div>

        <table style="width:100%;border-collapse:collapse;font-size:13px;margin-bottom:12px">
          <thead>
            <tr style="border-bottom:2px solid var(--border);background:#f8fafc">
              <th style="padding:8px 12px;text-align:left;font-size:11px;color:var(--text-muted)">ITEM</th>
              <th style="padding:8px 12px;text-align:right;font-size:11px;color:var(--text-muted)">JUMLAH</th>
            </tr>
          </thead>
          <tbody>
            ${(p.items||[]).map(i=>`<tr style="border-bottom:1px solid #f1f5f9">
              <td style="padding:8px 12px">${i.name}</td>
              <td style="padding:8px 12px;text-align:right;font-weight:600">${App.fmt.currency(i.price)}</td>
            </tr>`).join('')}
          </tbody>
          <tfoot>
            <tr><td style="padding:6px 12px;font-size:12px">Subtotal</td><td style="padding:6px 12px;text-align:right;font-size:12px">${App.fmt.currency(p.subtotal)}</td></tr>
            ${p.discount ? `<tr><td style="padding:6px 12px;font-size:12px;color:var(--success)">Diskon</td><td style="padding:6px 12px;text-align:right;font-size:12px;color:var(--success)">-${App.fmt.currency(p.discount)}</td></tr>` : ''}
            ${p.adminFee ? `<tr><td style="padding:6px 12px;font-size:12px">Biaya Admin</td><td style="padding:6px 12px;text-align:right;font-size:12px">${App.fmt.currency(p.adminFee)}</td></tr>` : ''}
            <tr style="border-top:2px solid var(--border);background:var(--primary-subtle)">
              <td style="padding:10px 12px;font-weight:800;font-size:14px">TOTAL</td>
              <td style="padding:10px 12px;text-align:right;font-weight:800;font-size:14px;color:var(--primary)">${App.fmt.currency(p.total)}</td>
            </tr>
          </tfoot>
        </table>

        <div class="grid-2" style="gap:10px">
          <div class="info-row"><div class="info-label">Metode</div><div class="info-value font-semibold">${p.method}</div></div>
          ${p.insuranceNo ? `<div class="info-row"><div class="info-label">No. Asuransi</div><div class="info-value" style="font-family:monospace">${p.insuranceNo}</div></div>` : ''}
          <div class="info-row"><div class="info-label">Tgl. Bayar</div><div class="info-value">${App.fmt.datetime(p.paidAt)}</div></div>
          <div class="info-row"><div class="info-label">Kasir</div><div class="info-value">${DB.getOne('users',p.paidBy)?.name||p.paidBy||'—'}</div></div>
        </div>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Tutup</button>
        <button class="btn btn-outline-primary" onclick="Modules.Billing.printReceipt('${payId}')">
          ${App.icon('printer',14)} Cetak Nota
        </button>
      `
    });
  },

  printReceipt(payId) {
    const p = DB.getOne('payments', payId);
    const visit = DB.getOne('visits', p?.visitId);
    const pat = visit ? DB.getOne('patients', visit.patientId) : null;

    const w = window.open('', '_blank', 'width=380,height=600');
    w.document.write(`
      <html><head><title>Nota — ${payId}</title>
      <style>
        body{font-family:'Courier New',monospace;font-size:12px;padding:20px;width:300px}
        .center{text-align:center}.bold{font-weight:bold}
        .line{border-top:1px dashed #000;margin:8px 0}
        .flex{display:flex;justify-content:space-between}
      </style></head><body>
        <div class="center bold">RS RAKYAT SEJAHTERAH</div>
        <div class="center">Jl. Kesehatan No. 1, Jakarta</div>
        <div class="center">Telp: (021) 1234-5678</div>
        <div class="line"></div>
        <div class="center bold">NOTA PEMBAYARAN</div>
        <div class="line"></div>
        <div class="flex"><span>No. Nota</span><span>${p?.id}</span></div>
        <div class="flex"><span>Tanggal</span><span>${App.fmt.datetime(p?.paidAt)}</span></div>
        <div class="flex"><span>Pasien</span><span>${pat?.name||'—'}</span></div>
        <div class="flex"><span>No. MR</span><span>${pat?.id||'—'}</span></div>
        <div class="line"></div>
        ${(p?.items||[]).map(i=>`<div class="flex"><span>${i.name}</span><span>${App.fmt.currency(i.price)}</span></div>`).join('')}
        <div class="line"></div>
        <div class="flex bold"><span>TOTAL</span><span>${App.fmt.currency(p?.total)}</span></div>
        <div class="flex"><span>Metode</span><span>${p?.method}</span></div>
        <div class="line"></div>
        <div class="center">Terima kasih atas kepercayaan Anda</div>
        <div class="center">Semoga lekas sembuh 🙏</div>
      </body></html>`);
    w.document.close();
    setTimeout(() => w.print(), 500);
  }
};
