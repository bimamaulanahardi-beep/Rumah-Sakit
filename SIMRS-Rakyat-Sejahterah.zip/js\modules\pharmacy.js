/**
 * SIMRS — Pharmacy Module (Farmasi & Resep)
 */
Modules.Pharmacy = {
  activeTab: 'prescriptions',
  searchQuery: '',

  render(container) {
    const pendingRx = DB.get('prescriptions').filter(p => p.status === 'menunggu').length;

    container.innerHTML = `
      <div class="page-header fade-up">
        <div>
          <h2>Farmasi & Resep</h2>
          <p>Manajemen resep dan stok obat</p>
        </div>
        <div class="page-header-actions">
          ${this.activeTab === 'inventory' ? `
          <button class="btn btn-primary" onclick="Modules.Pharmacy.showMedForm(null)">
            ${App.icon('plus',14)} Tambah Obat
          </button>` : ''}
        </div>
      </div>

      <div class="tabs fade-up">
        <div class="tab-item ${this.activeTab==='prescriptions'?'active':''}" onclick="Modules.Pharmacy._switchTab('prescriptions')">
          ${App.icon('clipboard-list',14)} Resep Masuk
          ${pendingRx > 0 ? `<span class="tab-count">${pendingRx}</span>` : ''}
        </div>
        <div class="tab-item ${this.activeTab==='inventory'?'active':''}" onclick="Modules.Pharmacy._switchTab('inventory')">
          ${App.icon('package',14)} Stok Obat
          <span class="tab-count">${DB.count('medications')}</span>
        </div>
      </div>

      <div id="pharmacy-content" class="fade-up"></div>
    `;

    this._renderActiveTab();
  },

  _switchTab(tab) {
    this.activeTab = tab;
    document.querySelectorAll('.tab-item').forEach((t,i) => t.classList.toggle('active', (i===0&&tab==='prescriptions')||(i===1&&tab==='inventory')));
    const actionsEl = document.querySelector('.page-header-actions');
    if (actionsEl) {
      actionsEl.innerHTML = tab === 'inventory' ? `<button class="btn btn-primary" onclick="Modules.Pharmacy.showMedForm(null)">${App.icon('plus',14)} Tambah Obat</button>` : '';
    }
    this._renderActiveTab();
  },

  _renderActiveTab() {
    const el = document.getElementById('pharmacy-content');
    if (!el) return;
    if (this.activeTab === 'prescriptions') {
      el.innerHTML = this._prescriptionsHTML();
    } else {
      el.innerHTML = this._inventoryHTML();
    }
  },

  _prescriptionsHTML() {
    const rxList = DB.get('prescriptions').sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
    const filtered = rxList.filter(rx => {
      if (!this.searchQuery) return true;
      const visit = DB.getOne('visits', rx.visitId);
      const pat = visit ? DB.getOne('patients', visit.patientId) : null;
      return (pat?.name||'').toLowerCase().includes(this.searchQuery.toLowerCase()) ||
             rx.medications?.some(m => m.name.toLowerCase().includes(this.searchQuery.toLowerCase()));
    });

    return `
      <div class="card">
        <div class="card-header">
          <div class="search-bar" style="max-width:260px;flex:1">
            ${App.icon('search',15,'search-icon')}
            <input type="text" placeholder="Cari nama pasien/obat..." value="${this.searchQuery}"
              oninput="Modules.Pharmacy.searchQuery=this.value;Modules.Pharmacy._renderActiveTab()" />
          </div>
          <div class="flex gap-2">
            <span class="badge badge-warning">${rxList.filter(r=>r.status==='menunggu').length} Menunggu</span>
            <span class="badge badge-success">${rxList.filter(r=>r.status==='diserahkan').length} Diserahkan</span>
          </div>
        </div>
        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead>
              <tr><th>ID Resep</th><th>Pasien</th><th>Obat</th><th>Tgl. Dibuat</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
              ${filtered.length === 0 ? `<tr><td colspan="6"><div class="empty-state">${App.icon('clipboard-list',40,'','color:var(--text-placeholder)')}<h4>Tidak ada resep</h4></div></td></tr>` :
              filtered.map(rx => {
                const visit = DB.getOne('visits', rx.visitId);
                const pat = visit ? DB.getOne('patients', visit.patientId) : null;
                return `
                  <tr>
                    <td><code style="font-size:11px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${rx.id}</code></td>
                    <td>
                      <div class="flex items-center gap-2">
                        <div class="avatar avatar-sm avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
                        <div class="font-semibold" style="font-size:13px">${pat?.name||'—'}</div>
                      </div>
                    </td>
                    <td>
                      <div style="font-size:12px">
                        ${(rx.medications||[]).slice(0,2).map(m=>`<div>${m.name} × ${m.qty}</div>`).join('')}
                        ${rx.medications?.length > 2 ? `<div style="color:var(--text-muted)">+${rx.medications.length-2} lagi</div>` : ''}
                      </div>
                    </td>
                    <td style="font-size:12px;white-space:nowrap">${App.fmt.datetime(rx.createdAt)}</td>
                    <td>${App.statusBadge(rx.status)}</td>
                    <td>
                      <div class="flex gap-1">
                        <button class="btn btn-xs btn-outline-primary" onclick="Modules.Pharmacy.showRxDetail('${rx.id}')">${App.icon('eye',12)} Detail</button>
                        ${rx.status === 'menunggu' ? `<button class="btn btn-xs btn-success" onclick="Modules.Pharmacy.dispensePrescription('${rx.id}')">${App.icon('check',12)} Serahkan</button>` : ''}
                      </div>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  _inventoryHTML() {
    const meds = DB.search('medications', this.searchQuery, ['name','genericName','category']);

    return `
      <div class="card">
        <div class="card-header">
          <div class="search-bar" style="max-width:260px;flex:1">
            ${App.icon('search',15,'search-icon')}
            <input type="text" placeholder="Cari nama obat, kategori..." value="${this.searchQuery}"
              oninput="Modules.Pharmacy.searchQuery=this.value;Modules.Pharmacy._renderActiveTab()" />
          </div>
          <div class="flex gap-2">
            <span class="badge badge-danger">${DB.get('medications').filter(m=>m.stock<=m.minStock).length} Stok Menipis</span>
          </div>
        </div>
        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead>
              <tr><th>Nama Obat</th><th>Generik</th><th>Kategori</th><th>Stok</th><th>Min. Stok</th><th>Harga</th><th>Exp.</th><th>Aksi</th></tr>
            </thead>
            <tbody>
              ${meds.length === 0 ? `<tr><td colspan="8"><div class="empty-state">${App.icon('package',40,'','color:var(--text-placeholder)')}<h4>Tidak ada obat</h4></div></td></tr>` :
              meds.map(m => {
                const isLow = m.stock <= m.minStock;
                const isOut = m.stock === 0;
                const expDate = new Date(m.expiryDate);
                const isExpired = expDate < new Date();
                const isNearExp = !isExpired && expDate < new Date(Date.now() + 30*86400000);
                return `
                  <tr>
                    <td>
                      <div class="font-semibold" style="font-size:13px">${m.name}</div>
                      <div style="font-size:11px;color:var(--text-muted)">${m.manufacturer||''}</div>
                    </td>
                    <td style="font-size:12px">${m.genericName||'-'}</td>
                    <td><span class="badge badge-neutral" style="font-size:10.5px">${m.category||''}</span></td>
                    <td>
                      <div class="flex items-center gap-2">
                        <span style="font-weight:700;color:${isOut?'var(--danger)':isLow?'var(--warning)':'var(--success)'}">
                          ${m.stock}
                        </span>
                        <span style="font-size:11px;color:var(--text-muted)">${m.unit}</span>
                        ${isLow ? `<span class="badge badge-${isOut?'danger':'warning'}" style="font-size:9.5px">${isOut?'Habis':'Menipis'}</span>` : ''}
                      </div>
                    </td>
                    <td style="font-size:12px">${m.minStock} ${m.unit}</td>
                    <td style="font-size:12px">${App.fmt.currency(m.price)}</td>
                    <td style="font-size:12px">
                      <span style="color:${isExpired?'var(--danger)':isNearExp?'var(--warning)':'var(--text-secondary)'}">
                        ${App.fmt.dateShort(m.expiryDate)}
                        ${isExpired ? '⚠' : isNearExp ? '⚡' : ''}
                      </span>
                    </td>
                    <td>
                      <div class="flex gap-1">
                        <button class="btn btn-icon-sm btn-ghost" onclick="Modules.Pharmacy.showMedForm('${m.id}')">${App.icon('edit',13)}</button>
                        <button class="btn btn-icon-sm btn-ghost" style="color:var(--danger)" onclick="Modules.Pharmacy.deleteMed('${m.id}')">${App.icon('trash',13)}</button>
                      </div>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  showRxDetail(rxId) {
    const rx = DB.getOne('prescriptions', rxId);
    if (!rx) return;
    const visit = DB.getOne('visits', rx.visitId);
    const pat = visit ? DB.getOne('patients', visit.patientId) : null;
    const doc = visit ? DB.getOne('doctors', visit.doctorId) : null;

    App.modal({
      title: `Detail Resep — ${rx.id}`,
      subtitle: `${pat?.name||''} · ${App.fmt.date(visit?.date)}`,
      body: `
        <div class="flex gap-3 items-center p-3 mb-4" style="background:#f8fafc;border-radius:var(--radius-sm);border:1px solid var(--border)">
          <div class="avatar avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
          <div class="flex-1">
            <div class="font-bold">${pat?.name||'—'}</div>
            <div style="font-size:12px;color:var(--text-muted)">${pat?.id} · ${doc?.name?.split(',')[0]||''} · ${App.fmt.dateShort(visit?.date)}</div>
          </div>
          ${App.statusBadge(rx.status)}
        </div>

        <div style="margin-bottom:16px">
          ${(rx.medications||[]).map(m => `
            <div class="rx-item">
              <div>
                <div class="rx-item-name">${m.name}</div>
                <div class="rx-item-detail">${m.dose} · ${m.frequency} · ${m.notes||''}</div>
              </div>
              <div style="text-align:right">
                <div class="font-bold">${m.qty} ${m.unit}</div>
                <div style="font-size:11px;color:var(--text-muted)">${App.fmt.currency((DB.getOne('medications',m.medicationId)?.price||0)*m.qty)}</div>
              </div>
            </div>`).join('')}
        </div>

        ${rx.notes ? `<div class="alert alert-info">${App.icon('info',14)} ${rx.notes}</div>` : ''}

        ${rx.status === 'diserahkan' ? `
          <div class="alert alert-success">
            ${App.icon('check-circle',14)}
            Diserahkan oleh ${DB.getOne('users',rx.dispensedBy)?.name||rx.dispensedBy} pada ${App.fmt.datetime(rx.dispensedAt)}
          </div>` : ''}
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Tutup</button>
        ${rx.status === 'menunggu' ? `
          <button class="btn btn-success" onclick="App.closeModal();Modules.Pharmacy.dispensePrescription('${rxId}')">
            ${App.icon('check',14)} Serahkan Obat
          </button>` : ''}
      `
    });
  },

  dispensePrescription(rxId) {
    const rx = DB.getOne('prescriptions', rxId);
    if (!rx) return;

    // Check stock
    const stockErrors = [];
    rx.medications.forEach(m => {
      const med = DB.getOne('medications', m.medicationId);
      if (med && med.stock < m.qty) {
        stockErrors.push(`${m.name}: stok ${med.stock}, dibutuhkan ${m.qty}`);
      }
    });

    if (stockErrors.length > 0) {
      App.toast(`Stok tidak mencukupi: ${stockErrors.join('; ')}`, 'error');
      return;
    }

    App.confirm({
      title: 'Serahkan Obat',
      message: `Yakin menyerahkan resep ini? Stok obat akan dikurangi sesuai resep.`,
      confirmLabel: 'Serahkan',
      confirmClass: 'btn-success',
      onConfirm: () => {
        // Reduce stock
        rx.medications.forEach(m => {
          const med = DB.getOne('medications', m.medicationId);
          if (med) DB.update('medications', m.medicationId, { stock: med.stock - m.qty });
        });
        // Update prescription status
        DB.update('prescriptions', rxId, {
          status: 'diserahkan',
          dispensedBy: App.user.id,
          dispensedAt: new Date().toISOString()
        });
        App.toast('Obat berhasil diserahkan ke pasien', 'success');
        Modules.Pharmacy._renderActiveTab();
      }
    });
  },

  showMedForm(id) {
    const m = id ? DB.getOne('medications', id) : null;
    const categories = ['Analgesik/Antipiretik','Antibiotik','NSAID','Antihipertensi','Antidiabetik','Antihistamin','Lambung','Kolesterol','Bronkodilator','Kortikosteroid','Antitusif','Vitamin','Cairan Infus','Lain-lain'];

    App.modal({
      title: m ? 'Edit Data Obat' : 'Tambah Obat Baru',
      size: 'modal-lg',
      body: `
        <form id="medForm" onsubmit="Modules.Pharmacy.saveMed(event,'${id||''}')">
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">Nama Obat <span class="required">*</span></label>
              <input class="form-control" name="name" required value="${m?.name||''}" placeholder="Nama dagang / sediaan" />
            </div>
            <div class="form-group">
              <label class="form-label">Nama Generik</label>
              <input class="form-control" name="genericName" value="${m?.genericName||''}" placeholder="Nama zat aktif" />
            </div>
            <div class="form-group">
              <label class="form-label">Kategori <span class="required">*</span></label>
              <select class="form-control" name="category" required>
                ${categories.map(c=>`<option value="${c}" ${m?.category===c?'selected':''}>${c}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Satuan <span class="required">*</span></label>
              <select class="form-control" name="unit" required>
                ${['Tablet','Kapsul','Botol','Ampul','Vial','Sachet','Tube','Lembar'].map(u=>`<option value="${u}" ${m?.unit===u?'selected':''}>${u}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Stok Saat Ini <span class="required">*</span></label>
              <input type="number" class="form-control" name="stock" required value="${m?.stock||0}" min="0" />
            </div>
            <div class="form-group">
              <label class="form-label">Stok Minimum <span class="required">*</span></label>
              <input type="number" class="form-control" name="minStock" required value="${m?.minStock||20}" min="0" />
            </div>
            <div class="form-group">
              <label class="form-label">Harga per Satuan (Rp)</label>
              <input type="number" class="form-control" name="price" value="${m?.price||0}" min="0" />
            </div>
            <div class="form-group">
              <label class="form-label">Tanggal Kadaluarsa</label>
              <input type="date" class="form-control" name="expiryDate" value="${m?.expiryDate||''}" />
            </div>
            <div class="form-group">
              <label class="form-label">Produsen</label>
              <input class="form-control" name="manufacturer" value="${m?.manufacturer||''}" placeholder="Nama pabrik obat" />
            </div>
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-primary" onclick="document.getElementById('medForm').requestSubmit()">
          ${App.icon('save',14)} ${m ? 'Simpan' : 'Tambah Obat'}
        </button>
      `
    });
  },

  saveMed(e, id) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    data.stock = parseInt(data.stock);
    data.minStock = parseInt(data.minStock);
    data.price = parseInt(data.price);

    if (id) {
      DB.update('medications', id, data);
      App.toast('Data obat berhasil diperbarui', 'success');
    } else {
      DB.insert('medications', { id: 'MED' + Date.now().toString().slice(-6), ...data });
      App.toast('Obat berhasil ditambahkan', 'success');
    }
    App.closeModal();
    this._renderActiveTab();
  },

  deleteMed(id) {
    const m = DB.getOne('medications', id);
    App.confirm({
      title: 'Hapus Data Obat',
      message: `Yakin menghapus <strong>${m?.name}</strong>? Data tidak dapat dikembalikan.`,
      confirmLabel: 'Hapus',
      onConfirm: () => {
        DB.delete('medications', id);
        App.toast('Obat dihapus', 'info');
        Modules.Pharmacy._renderActiveTab();
      }
    });
  }
};
