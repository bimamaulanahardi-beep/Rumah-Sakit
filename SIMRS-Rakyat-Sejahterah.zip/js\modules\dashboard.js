/**
 * SIMRS — Dashboard Module
 */
Modules.Dashboard = {
  render(container) {
    const today = new Date().toISOString().split('T')[0];
    const todayVisits = DB.get('visits').filter(v => v.date === today);
    const todayQueue  = DB.get('queues').filter(q => q.date === today);
    const waitingQ    = todayQueue.filter(q => q.status === 'menunggu').length;
    const doneQ       = todayQueue.filter(q => q.status === 'selesai').length;
    const pendingRx   = DB.get('prescriptions').filter(p => p.status === 'menunggu').length;
    const pendingLab  = DB.get('labOrders').filter(l => l.status !== 'selesai').length;
    const totalPat    = DB.count('patients');

    const recentVisits = DB.get('visits').sort((a,b)=>new Date(b.createdAt||b.date)-new Date(a.createdAt||a.date)).slice(0,5);
    const doctors = DB.get('doctors');
    const patients = DB.get('patients');
    const lowStock = DB.get('medications').filter(m => m.stock <= m.minStock);

    container.innerHTML = `
      <div class="page-header fade-up">
        <div>
          <h2>Selamat Datang, ${App.user.name.split(' ').slice(0,2).join(' ')} 👋</h2>
          <p>${new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'})} — RS Rakyat Sejahterah</p>
        </div>
        <button class="btn btn-primary btn-sm" onclick="App.navigate('scheduling')">
          ${App.icon('plus',14)} Daftar Pasien Baru
        </button>
      </div>

      <!-- Stats -->
      <div class="stats-grid stagger">
        <div class="stat-card fade-up">
          <div class="stat-icon" style="background:var(--primary-subtle)">${App.icon('users',24,'','color:var(--primary)')}</div>
          <div class="stat-body">
            <h3>${todayVisits.length}</h3>
            <p>Kunjungan Hari Ini</p>
            <div class="stat-trend up">${App.icon('trending-up',11)} ${totalPat} total pasien</div>
          </div>
        </div>
        <div class="stat-card fade-up">
          <div class="stat-icon" style="background:var(--warning-subtle)">${App.icon('clock',24,'','color:var(--warning)')}</div>
          <div class="stat-body">
            <h3>${waitingQ}</h3>
            <p>Antrian Menunggu</p>
            <div class="stat-trend" style="color:var(--text-muted)">${doneQ} sudah selesai</div>
          </div>
        </div>
        <div class="stat-card fade-up">
          <div class="stat-icon" style="background:var(--purple-subtle)">${App.icon('pill',24,'','color:var(--purple)')}</div>
          <div class="stat-body">
            <h3>${pendingRx}</h3>
            <p>Resep Menunggu</p>
            <div class="stat-trend ${pendingRx > 0 ? 'down' : 'up'}">${pendingRx > 0 ? '⚠ Segera proses' : '✓ Semua beres'}</div>
          </div>
        </div>
        <div class="stat-card fade-up">
          <div class="stat-icon" style="background:var(--info-subtle)">${App.icon('microscope',24,'','color:var(--info)')}</div>
          <div class="stat-body">
            <h3>${pendingLab}</h3>
            <p>Lab Pending</p>
            <div class="stat-trend ${pendingLab > 0 ? 'down' : 'up'}">${pendingLab > 0 ? '⚠ Perlu tindakan' : '✓ Semua selesai'}</div>
          </div>
        </div>
      </div>

      ${lowStock.length > 0 ? `
      <div class="alert alert-warning mb-4">
        ${App.icon('alert-triangle',16)}
        <div><strong>Stok Menipis:</strong> ${lowStock.map(m=>m.name).join(', ')}. Segera lakukan pengadaan.</div>
      </div>` : ''}

      <!-- Main content grid -->
      <div style="display:grid;grid-template-columns:1fr 360px;gap:16px;align-items:start">

        <!-- Left: Recent Visits + Queue Today -->
        <div style="display:flex;flex-direction:column;gap:16px">

          <!-- Today's Queue -->
          <div class="card fade-up">
            <div class="card-header">
              <span class="card-title">${App.icon('hash',16)} Antrian Hari Ini</span>
              <button class="btn btn-outline-primary btn-sm" onclick="App.navigate('scheduling')">Lihat Semua</button>
            </div>
            <div class="table-container" style="border:none;border-radius:0">
              <table class="table">
                <thead>
                  <tr>
                    <th>No.</th><th>Pasien</th><th>Dokter</th><th>Keluhan</th><th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  ${todayVisits.length === 0 ? `<tr><td colspan="5"><div class="empty-state" style="padding:24px">${App.icon('calendar',32,'','color:var(--text-placeholder)')} <p>Belum ada kunjungan hari ini</p></div></td></tr>` :
                    todayVisits.map(v => {
                      const pat = DB.getOne('patients', v.patientId);
                      const doc = DB.getOne('doctors', v.doctorId);
                      return `
                        <tr style="cursor:pointer" onclick="App.navigate('emr')">
                          <td><div class="queue-number" style="font-size:18px;letter-spacing:-0.5px">${String(v.queueNo).padStart(3,'0')}</div></td>
                          <td>
                            <div class="flex items-center gap-2">
                              <div class="avatar avatar-sm avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
                              <div>
                                <div class="font-semibold" style="font-size:13px">${pat?.name||'-'}</div>
                                <div style="font-size:11px;color:var(--text-muted)">${pat?.insurance||'Mandiri'}</div>
                              </div>
                            </div>
                          </td>
                          <td style="font-size:12px;color:var(--text-secondary)">${doc?.name?.split(',')[0]||'-'}</td>
                          <td style="font-size:12px;max-width:180px" class="truncate">${v.chiefComplaint||'-'}</td>
                          <td>${App.statusBadge(v.status)}</td>
                        </tr>`;
                    }).join('')}
                </tbody>
              </table>
            </div>
          </div>

          <!-- Recent Visits chart -->
          <div class="card fade-up">
            <div class="card-header">
              <span class="card-title">${App.icon('activity',16)} Aktivitas Kunjungan (7 Hari)</span>
            </div>
            <div class="card-body">
              <div class="chart-container"><canvas id="chartWeekly"></canvas></div>
            </div>
          </div>
        </div>

        <!-- Right: Doctors + Low Stock -->
        <div style="display:flex;flex-direction:column;gap:16px">

          <!-- Doctors on duty -->
          <div class="card fade-up">
            <div class="card-header">
              <span class="card-title">${App.icon('award',16)} Dokter Praktik Hari Ini</span>
            </div>
            <div class="card-body" style="padding:12px 16px">
              ${this._doctorsOnDuty(doctors)}
            </div>
          </div>

          <!-- Low stock -->
          ${lowStock.length > 0 ? `
          <div class="card fade-up">
            <div class="card-header">
              <span class="card-title">${App.icon('package',16)} Stok Menipis</span>
              <button class="btn btn-sm btn-outline-primary" onclick="App.navigate('pharmacy')">${App.icon('arrow-right',12)} Farmasi</button>
            </div>
            <div class="card-body" style="padding:8px 16px">
              ${lowStock.slice(0,5).map(m => `
                <div class="flex items-center justify-between" style="padding:8px 0;border-bottom:1px solid var(--border)">
                  <div>
                    <div style="font-size:13px;font-weight:600">${m.name}</div>
                    <div style="font-size:11px;color:var(--text-muted)">Min: ${m.minStock} ${m.unit}</div>
                  </div>
                  <span class="badge ${m.stock === 0 ? 'badge-danger' : 'badge-warning'}">${m.stock} ${m.unit}</span>
                </div>
              `).join('')}
            </div>
          </div>` : ''}

          <!-- Quick actions -->
          <div class="card fade-up">
            <div class="card-header"><span class="card-title">${App.icon('layers',16)} Akses Cepat</span></div>
            <div class="card-body" style="padding:12px;display:grid;grid-template-columns:1fr 1fr;gap:8px">
              ${[
                {module:'patients',icon:'users',label:'Pasien',color:'primary',roles:['admin','dokter']},
                {module:'scheduling',icon:'calendar-clock',label:'Antrian',color:'warning',roles:['admin','dokter']},
                {module:'emr',icon:'file-text',label:'Rekam Medis',color:'info',roles:['admin','dokter']},
                {module:'pharmacy',icon:'pill',label:'Farmasi',color:'purple',roles:['admin','apoteker']},
                {module:'billing',icon:'receipt',label:'Billing',color:'success',roles:['admin','kasir']},
                {module:'laboratory',icon:'microscope',label:'Lab',color:'teal',roles:['admin','lab']},
              ].filter(a => a.roles.includes(App.user.role)).map(a => `
                <button class="btn btn-secondary" style="flex-direction:column;gap:4px;height:72px;font-size:11.5px" onclick="App.navigate('${a.module}')">
                  <div style="width:30px;height:30px;border-radius:8px;background:var(--${a.color}-subtle);display:flex;align-items:center;justify-content:center">
                    ${App.icon(a.icon,16,'','color:var(--'+a.color+')')}
                  </div>
                  ${a.label}
                </button>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;

    this._drawWeeklyChart();
  },

  _doctorsOnDuty(doctors) {
    const dayName = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][new Date().getDay()];
    const schedules = DB.get('schedules').filter(s => s.day === dayName && s.isActive);
    if (schedules.length === 0) return `<p style="color:var(--text-muted);font-size:13px;padding:8px 0">Tidak ada dokter praktik hari ini</p>`;
    return schedules.map(s => {
      const doc = DB.getOne('doctors', s.doctorId);
      if (!doc) return '';
      const todayVisitsDoc = DB.get('visits').filter(v => v.doctorId === doc.id && v.date === new Date().toISOString().split('T')[0]);
      return `
        <div class="flex items-center gap-3" style="padding:8px 0;border-bottom:1px solid var(--border)">
          <div class="avatar avatar-sm avatar-${doc.color||'blue'}">${doc.avatar}</div>
          <div class="flex-1" style="min-width:0">
            <div class="font-semibold truncate" style="font-size:12.5px">${doc.name.split(',')[0]}</div>
            <div style="font-size:11px;color:var(--text-muted)">${doc.specialization} · ${s.startTime}–${s.endTime}</div>
          </div>
          <span class="badge badge-primary">${todayVisitsDoc.length}/${s.quota}</span>
        </div>`;
    }).join('');
  },

  _drawWeeklyChart() {
    const ctx = document.getElementById('chartWeekly');
    if (!ctx || !window.Chart) return;
    const visits = DB.get('visits');
    const days = [];
    const counts = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const dateStr = d.toISOString().split('T')[0];
      days.push(d.toLocaleDateString('id-ID',{weekday:'short',day:'numeric'}));
      counts.push(visits.filter(v => v.date === dateStr).length);
    }
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: days,
        datasets: [{
          label: 'Kunjungan',
          data: counts,
          borderColor: '#3b82f6',
          backgroundColor: 'rgba(59,130,246,0.08)',
          borderWidth: 2.5,
          pointBackgroundColor: '#3b82f6',
          pointRadius: 4,
          tension: 0.4,
          fill: true,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#f1f5f9' } },
          x: { grid: { display: false } }
        }
      }
    });
  }
};
