/**
 * SIMRS — Scheduling Module (Jadwal Dokter & Antrian)
 */
Modules.Scheduling = {
  activeTab: 'queue',

  render(container) {
    const today = new Date().toISOString().split('T')[0];
    const dayName = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][new Date().getDay()];
    const doctors = DB.get('doctors');
    const schedules = DB.get('schedules').filter(s => s.day === dayName && s.isActive);
    const todayVisits = DB.get('visits').filter(v => v.date === today);
    const queues = DB.get('queues').filter(q => q.date === today);

    container.innerHTML = `
      <div class="page-header fade-up">
        <div>
          <h2>Jadwal & Antrian</h2>
          <p>${dayName}, ${App.fmt.date(today)} — ${todayVisits.length} kunjungan terdaftar</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary" onclick="Modules.Scheduling.showNewVisitForm()">
            ${App.icon('plus',14)} Daftar Pasien
          </button>
        </div>
      </div>

      <div class="tabs fade-up">
        <div class="tab-item ${this.activeTab==='queue'?'active':''}" onclick="Modules.Scheduling._switchTab('queue','${today}','${dayName}')">
          ${App.icon('hash',14)} Antrian Hari Ini <span class="tab-count">${todayVisits.length}</span>
        </div>
        <div class="tab-item ${this.activeTab==='schedule'?'active':''}" onclick="Modules.Scheduling._switchTab('schedule','${today}','${dayName}')">
          ${App.icon('calendar',14)} Jadwal Dokter
        </div>
      </div>

      <div id="scheduling-content" class="fade-up"></div>
    `;

    this._renderActiveTab(today, dayName, doctors, schedules, todayVisits, queues);
  },

  _switchTab(tab, today, dayName) {
    this.activeTab = tab;
    document.querySelectorAll('.tab-item').forEach((t,i) => t.classList.toggle('active', (i===0&&tab==='queue')||(i===1&&tab==='schedule')));
    const doctors = DB.get('doctors');
    const schedules = DB.get('schedules').filter(s => s.day === dayName && s.isActive);
    const todayVisits = DB.get('visits').filter(v => v.date === today);
    const queues = DB.get('queues').filter(q => q.date === today);
    this._renderActiveTab(today, dayName, doctors, schedules, todayVisits, queues);
  },

  _renderActiveTab(today, dayName, doctors, schedules, todayVisits, queues) {
    const el = document.getElementById('scheduling-content');
    if (!el) return;
    if (this.activeTab === 'queue') {
      el.innerHTML = this._queueHTML(doctors, todayVisits, queues, today);
    } else {
      el.innerHTML = this._schedulesHTML(doctors, schedules, dayName);
    }
  },

  _queueHTML(doctors, todayVisits, queues, today) {
    const docIds = [...new Set(todayVisits.map(v => v.doctorId))];

    if (todayVisits.length === 0) {
      return `<div class="card"><div class="empty-state" style="padding:48px">
        ${App.icon('calendar-clock',48,'','color:var(--text-placeholder)')}
        <h4>Belum Ada Antrian</h4>
        <p>Belum ada pasien terdaftar untuk hari ini.</p>
        <button class="btn btn-primary" onclick="Modules.Scheduling.showNewVisitForm()">Daftar Pasien Baru</button>
      </div></div>`;
    }

    return docIds.map(docId => {
      const doc = DB.getOne('doctors', docId);
      const docVisits = todayVisits.filter(v => v.doctorId === docId).sort((a,b) => a.queueNo - b.queueNo);
      const waiting = docVisits.filter(v => v.status === 'menunggu').length;
      const called = docVisits.filter(v => v.status === 'dipanggil').length;
      const done = docVisits.filter(v => v.status === 'selesai').length;

      return `
        <div class="card mb-4">
          <div class="card-header">
            <div class="flex items-center gap-3">
              <div class="avatar avatar-${doc?.color||'blue'}">${doc?.avatar||'DR'}</div>
              <div>
                <div class="card-title">${doc?.name||'Unknown'}</div>
                <div class="card-subtitle">${doc?.specialization||''} · ${doc?.room||''}</div>
              </div>
            </div>
            <div class="flex gap-2">
              <span class="badge badge-warning">${waiting} Menunggu</span>
              <span class="badge badge-info">${called} Dipanggil</span>
              <span class="badge badge-success">${done} Selesai</span>
            </div>
          </div>
          <div class="table-container" style="border:none;border-radius:0">
            <table class="table">
              <thead>
                <tr><th>No.</th><th>Pasien</th><th>Keluhan</th><th>Asuransi</th><th>Status</th><th>Aksi</th></tr>
              </thead>
              <tbody>
                ${docVisits.map(v => {
                  const pat = DB.getOne('patients', v.patientId);
                  return `
                    <tr class="${v.status==='dipanggil'?'':''}">
                      <td>
                        <div class="queue-number" style="font-size:20px">${String(v.queueNo).padStart(3,'0')}</div>
                      </td>
                      <td>
                        <div class="flex items-center gap-2">
                          <div class="avatar avatar-sm avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
                          <div>
                            <div class="font-semibold" style="font-size:13px">${pat?.name||'-'}</div>
                            <div style="font-size:11px;color:var(--text-muted)">${App.fmt.age(pat?.birthDate)} · ${App.fmt.genderLabel(pat?.gender)}</div>
                          </div>
                        </div>
                      </td>
                      <td style="font-size:12px;max-width:200px" class="truncate">${v.chiefComplaint||'-'}</td>
                      <td><span class="badge ${pat?.insurance==='BPJS'?'badge-success':'badge-neutral'}">${pat?.insurance||'Mandiri'}</span></td>
                      <td>${App.statusBadge(v.status)}</td>
                      <td>
                        <div class="flex gap-1">
                          ${v.status === 'menunggu' ? `
                            <button class="btn btn-xs btn-info" onclick="Modules.Scheduling.callPatient('${v.id}')">
                              ${App.icon('send',11)} Panggil
                            </button>` : ''}
                          ${v.status === 'dipanggil' ? `
                            <button class="btn btn-xs btn-success" onclick="Modules.Scheduling.startEMR('${v.id}','${v.patientId}','${v.doctorId}')">
                              ${App.icon('file-text',11)} Periksa
                            </button>
                            <button class="btn btn-xs btn-secondary" onclick="Modules.Scheduling.callPatient('${v.id}')">
                              ${App.icon('refresh-cw',11)}
                            </button>` : ''}
                          ${v.status === 'selesai' ? `
                            <button class="btn btn-xs btn-ghost" onclick="App.navigate('emr')">
                              ${App.icon('eye',11)} EMR
                            </button>` : ''}
                          <button class="btn btn-icon-sm btn-ghost" style="color:var(--danger)" onclick="Modules.Scheduling.cancelVisit('${v.id}')" title="Batalkan">${App.icon('x',12)}</button>
                        </div>
                      </td>
                    </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>`;
    }).join('');
  },

  _schedulesHTML(doctors, schedules, dayName) {
    return `
      <div class="flex justify-between items-center mb-4">
        <div style="font-size:13px;color:var(--text-secondary)">Jadwal praktik hari <strong>${dayName}</strong></div>
        <button class="btn btn-primary btn-sm" onclick="Modules.Scheduling.showScheduleForm()">
          ${App.icon('plus',13)} Tambah Jadwal
        </button>
      </div>

      ${schedules.length === 0 ? `
        <div class="card">
          <div class="empty-state">${App.icon('calendar',40,'','color:var(--text-placeholder)')}<h4>Tidak ada jadwal hari ini</h4></div>
        </div>` :
      `<div class="grid-auto">
        ${schedules.map(s => {
          const doc = DB.getOne('doctors', s.doctorId);
          const todayVisits = DB.get('visits').filter(v => v.doctorId === s.doctorId && v.date === new Date().toISOString().split('T')[0]);
          return `
            <div class="card">
              <div class="card-body">
                <div class="flex items-center gap-3 mb-3">
                  <div class="avatar avatar-${doc?.color||'blue'}">${doc?.avatar||'DR'}</div>
                  <div class="flex-1">
                    <div class="font-semibold">${doc?.name||'Unknown'}</div>
                    <div style="font-size:12px;color:var(--text-muted)">${doc?.specialization}</div>
                  </div>
                  <div class="dropdown">
                    <button class="btn btn-icon-sm btn-ghost" onclick="this.closest('.dropdown').querySelector('.dropdown-menu').classList.toggle('open')">
                      ${App.icon('more-vertical',14)}
                    </button>
                    <div class="dropdown-menu">
                      <div class="dropdown-item" onclick="Modules.Scheduling.showScheduleForm('${s.id}')">${App.icon('edit',14)} Edit Jadwal</div>
                      <div class="dropdown-item danger" onclick="Modules.Scheduling.deleteSchedule('${s.id}')">${App.icon('trash',14)} Hapus</div>
                    </div>
                  </div>
                </div>
                <div class="info-row"><div class="info-label">Hari</div><div class="info-value font-semibold">${s.day}</div></div>
                <div class="info-row"><div class="info-label">Waktu</div><div class="info-value">${s.startTime} – ${s.endTime}</div></div>
                <div class="info-row"><div class="info-label">Ruangan</div><div class="info-value">${doc?.room||'-'}</div></div>
                <div class="info-row"><div class="info-label">Terisi</div>
                  <div class="info-value">
                    <div style="display:flex;align-items:center;gap:8px">
                      <div style="flex:1;height:6px;background:#f1f5f9;border-radius:3px">
                        <div style="height:100%;width:${Math.min(100,Math.round(todayVisits.length/s.quota*100))}%;background:var(--primary);border-radius:3px"></div>
                      </div>
                      <span style="font-size:12px">${todayVisits.length}/${s.quota}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>`;
        }).join('')}
      </div>`}

      <!-- All schedules table -->
      <div class="card mt-4">
        <div class="card-header"><span class="card-title">${App.icon('calendar',16)} Semua Jadwal</span></div>
        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead><tr><th>Dokter</th><th>Hari</th><th>Jam Mulai</th><th>Jam Selesai</th><th>Kuota</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
              ${DB.get('schedules').sort((a,b)=>['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'].indexOf(a.day)-['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'].indexOf(b.day)).map(s => {
                const doc = DB.getOne('doctors', s.doctorId);
                return `<tr>
                  <td>
                    <div class="flex items-center gap-2">
                      <div class="avatar avatar-sm avatar-${doc?.color||'blue'}">${doc?.avatar||'?'}</div>
                      <div style="font-size:13px;font-weight:500">${doc?.name?.split(',')[0]||'-'}</div>
                    </div>
                  </td>
                  <td style="font-size:13px;font-weight:600">${s.day}</td>
                  <td style="font-size:13px">${s.startTime}</td>
                  <td style="font-size:13px">${s.endTime}</td>
                  <td style="font-size:13px">${s.quota}</td>
                  <td><span class="badge ${s.isActive?'badge-success':'badge-neutral'}">${s.isActive?'Aktif':'Nonaktif'}</span></td>
                  <td>
                    <div class="flex gap-1">
                      <button class="btn btn-icon-sm btn-ghost" onclick="Modules.Scheduling.showScheduleForm('${s.id}')">${App.icon('edit',13)}</button>
                      <button class="btn btn-icon-sm btn-ghost" style="color:var(--danger)" onclick="Modules.Scheduling.deleteSchedule('${s.id}')">${App.icon('trash',13)}</button>
                    </div>
                  </td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  showNewVisitForm() {
    const patients = DB.get('patients');
    const doctors = DB.get('doctors');
    const today = new Date().toISOString().split('T')[0];

    App.modal({
      title: 'Daftarkan Kunjungan Baru',
      body: `
        <form id="visitForm" onsubmit="Modules.Scheduling.saveVisit(event)">
          <div class="form-group">
            <label class="form-label">Pasien <span class="required">*</span></label>
            <select class="form-control" name="patientId" required>
              <option value="">Pilih pasien...</option>
              ${patients.map(p=>`<option value="${p.id}">${p.name} — NIK: ${p.nik||'-'}</option>`).join('')}
            </select>
            <div class="form-hint">Belum terdaftar? <a href="#" onclick="App.closeModal();Modules.Patients.showForm(null)" style="color:var(--primary)">Daftar pasien baru</a></div>
          </div>
          <div class="form-group">
            <label class="form-label">Dokter <span class="required">*</span></label>
            <select class="form-control" name="doctorId" required>
              <option value="">Pilih dokter...</option>
              ${doctors.map(d=>`<option value="${d.id}">${d.name} — ${d.specialization}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Tanggal Kunjungan <span class="required">*</span></label>
            <input type="date" class="form-control" name="date" value="${today}" required min="${today}" />
          </div>
          <div class="form-group">
            <label class="form-label">Keluhan Utama <span class="required">*</span></label>
            <textarea class="form-control" name="chiefComplaint" rows="2" required placeholder="Deskripsi keluhan pasien..."></textarea>
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-primary" onclick="document.getElementById('visitForm').requestSubmit()">
          ${App.icon('check',14)} Daftarkan
        </button>
      `
    });
  },

  saveVisit(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    const date = data.date;
    const queueNo = DB.get('visits').filter(v => v.doctorId === data.doctorId && v.date === date).length + 1;
    const visitId = 'VIS' + Date.now().toString().slice(-6);

    const visit = DB.insert('visits', {
      id: visitId, ...data, queueNo, status: 'menunggu',
      registeredBy: App.user.id
    });

    // Create queue entry
    DB.insert('queues', {
      id: 'QUE' + Date.now().toString().slice(-6),
      visitId: visitId, doctorId: data.doctorId,
      queueNo, status: 'menunggu', date, calledAt: null, completedAt: null
    });

    const pat = DB.getOne('patients', data.patientId);
    App.toast(`Pasien ${pat?.name||''} terdaftar. Nomor antrian: ${String(queueNo).padStart(3,'0')}`, 'success');
    App.closeModal();
    this.render(document.getElementById('content-area'));
  },

  callPatient(visitId) {
    DB.update('visits', visitId, { status: 'dipanggil' });
    DB.update('queues', DB.get('queues').find(q => q.visitId === visitId)?.id, { status: 'dipanggil', calledAt: new Date().toISOString() });
    App.toast('Pasien dipanggil', 'info');
    this.render(document.getElementById('content-area'));
  },

  startEMR(visitId, patientId, doctorId) {
    App.closeModal();
    App.navigate('emr');
    setTimeout(() => Modules.EMR.showForm(visitId), 300);
  },

  cancelVisit(visitId) {
    App.confirm({
      title: 'Batalkan Kunjungan',
      message: 'Yakin ingin membatalkan kunjungan ini?',
      confirmLabel: 'Batalkan',
      onConfirm: () => {
        DB.update('visits', visitId, { status: 'batal' });
        App.toast('Kunjungan dibatalkan', 'warning');
        Modules.Scheduling.render(document.getElementById('content-area'));
      }
    });
  },

  showScheduleForm(id) {
    const s = id ? DB.getOne('schedules', id) : null;
    const doctors = DB.get('doctors');
    const days = ['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'];

    App.modal({
      title: s ? 'Edit Jadwal' : 'Tambah Jadwal',
      body: `
        <form id="scheduleForm" onsubmit="Modules.Scheduling.saveSchedule(event,'${id||''}')">
          <div class="form-group">
            <label class="form-label">Dokter <span class="required">*</span></label>
            <select class="form-control" name="doctorId" required>
              ${doctors.map(d=>`<option value="${d.id}" ${s?.doctorId===d.id?'selected':''}>${d.name}</option>`).join('')}
            </select>
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">Hari <span class="required">*</span></label>
              <select class="form-control" name="day" required>
                ${days.map(d=>`<option value="${d}" ${s?.day===d?'selected':''}>${d}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Kuota Pasien</label>
              <input type="number" class="form-control" name="quota" value="${s?.quota||20}" min="1" max="100" />
            </div>
            <div class="form-group">
              <label class="form-label">Jam Mulai</label>
              <input type="time" class="form-control" name="startTime" value="${s?.startTime||'08:00'}" />
            </div>
            <div class="form-group">
              <label class="form-label">Jam Selesai</label>
              <input type="time" class="form-control" name="endTime" value="${s?.endTime||'12:00'}" />
            </div>
          </div>
          <div class="form-check">
            <input type="checkbox" name="isActive" id="isActiveCheck" ${!s||s.isActive?'checked':''} />
            <label class="form-check-label" for="isActiveCheck">Jadwal aktif</label>
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-primary" onclick="document.getElementById('scheduleForm').requestSubmit()">
          ${App.icon('save',14)} Simpan
        </button>
      `
    });
  },

  saveSchedule(e, id) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    data.isActive = !!e.target.isActive.checked;
    data.quota = parseInt(data.quota);

    if (id) {
      DB.update('schedules', id, data);
      App.toast('Jadwal berhasil diperbarui', 'success');
    } else {
      DB.insert('schedules', { id: 'SCH' + Date.now().toString().slice(-6), ...data });
      App.toast('Jadwal berhasil ditambahkan', 'success');
    }
    App.closeModal();
    this.render(document.getElementById('content-area'));
  },

  deleteSchedule(id) {
    App.confirm({
      title: 'Hapus Jadwal',
      message: 'Yakin ingin menghapus jadwal ini?',
      confirmLabel: 'Hapus',
      onConfirm: () => {
        DB.delete('schedules', id);
        App.toast('Jadwal dihapus', 'info');
        Modules.Scheduling.render(document.getElementById('content-area'));
      }
    });
  }
};
