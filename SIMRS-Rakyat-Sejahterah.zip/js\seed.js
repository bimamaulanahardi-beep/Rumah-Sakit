/**
 * SIMRS RS Rakyat Sejahterah
 * Seed Data — Demo data loader
 */

const Seed = {
  SEEDED_KEY: 'simrs_seeded_v3',

  init() {
    if (localStorage.getItem(this.SEEDED_KEY)) return;
    this.users();
    this.doctors();
    this.patients();
    this.medications();
    this.schedules();
    this.visits();
    this.emr();
    this.prescriptions();
    this.labOrders();
    this.payments();
    this.queues();
    localStorage.setItem(this.SEEDED_KEY, '1');
    console.log('[SIMRS] Seed data loaded successfully.');
  },

  reset() {
    const keys = ['users','doctors','patients','medications','schedules','visits','emr','prescriptions','labOrders','payments','queues'];
    keys.forEach(k => localStorage.removeItem('simrs_' + k));
    localStorage.removeItem(this.SEEDED_KEY);
    this.init();
  },

  users() {
    const users = [
      { id: 'USR001', username: 'admin', password: 'admin123', name: 'Administrator Sistem', role: 'admin', email: 'admin@rsrakyat.id', phone: '081234567890', isActive: true },
      { id: 'USR002', username: 'dr.ahmad', password: 'dokter123', name: 'dr. Ahmad Fauzi, Sp.PD', role: 'dokter', email: 'dr.ahmad@rsrakyat.id', phone: '081234567891', isActive: true, doctorId: 'DOC001' },
      { id: 'USR003', username: 'dr.sari', password: 'dokter123', name: 'dr. Sari Dewi, Sp.A', role: 'dokter', email: 'dr.sari@rsrakyat.id', phone: '081234567892', isActive: true, doctorId: 'DOC002' },
      { id: 'USR004', username: 'dr.hendra', password: 'dokter123', name: 'dr. Hendra Wijaya, Sp.B', role: 'dokter', email: 'dr.hendra@rsrakyat.id', phone: '081234567893', isActive: true, doctorId: 'DOC003' },
      { id: 'USR005', username: 'apoteker', password: 'farmasi123', name: 'Apt. Budi Santoso, S.Farm', role: 'apoteker', email: 'apoteker@rsrakyat.id', phone: '081234567894', isActive: true },
      { id: 'USR006', username: 'kasir', password: 'kasir123', name: 'Rina Hartati', role: 'kasir', email: 'kasir@rsrakyat.id', phone: '081234567895', isActive: true },
      { id: 'USR007', username: 'analis', password: 'lab123', name: 'Hendra Analis, A.Md.AK', role: 'lab', email: 'lab@rsrakyat.id', phone: '081234567896', isActive: true },
      { id: 'USR008', username: 'dr.maya', password: 'dokter123', name: 'dr. Maya Kusuma, Sp.OG', role: 'dokter', email: 'dr.maya@rsrakyat.id', phone: '081234567897', isActive: true, doctorId: 'DOC004' },
    ];
    users.forEach(u => DB.insert('users', u));
  },

  doctors() {
    const doctors = [
      { id: 'DOC001', userId: 'USR002', name: 'dr. Ahmad Fauzi, Sp.PD', specialization: 'Penyakit Dalam', phone: '081234567891', email: 'dr.ahmad@rsrakyat.id', consultationFee: 150000, room: 'Poli 1', avatar: 'AF', color: 'blue' },
      { id: 'DOC002', userId: 'USR003', name: 'dr. Sari Dewi, Sp.A', specialization: 'Anak', phone: '081234567892', email: 'dr.sari@rsrakyat.id', consultationFee: 150000, room: 'Poli 2', avatar: 'SD', color: 'green' },
      { id: 'DOC003', userId: 'USR004', name: 'dr. Hendra Wijaya, Sp.B', specialization: 'Bedah Umum', phone: '081234567893', email: 'dr.hendra@rsrakyat.id', consultationFee: 200000, room: 'Poli 3', avatar: 'HW', color: 'orange' },
      { id: 'DOC004', userId: 'USR008', name: 'dr. Maya Kusuma, Sp.OG', specialization: 'Kandungan & Kebidanan', phone: '081234567897', email: 'dr.maya@rsrakyat.id', consultationFee: 175000, room: 'Poli 4', avatar: 'MK', color: 'rose' },
      { id: 'DOC005', userId: null, name: 'dr. Rudi Setiawan', specialization: 'Dokter Umum', phone: '081234567898', email: 'dr.rudi@rsrakyat.id', consultationFee: 100000, room: 'Poli 5', avatar: 'RS', color: 'teal' },
    ];
    doctors.forEach(d => DB.insert('doctors', d));
  },

  schedules() {
    const days = ['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    const scheds = [
      // Dr Ahmad - Penyakit Dalam
      { doctorId: 'DOC001', day: 'Senin',  startTime: '08:00', endTime: '12:00', quota: 20, isActive: true },
      { doctorId: 'DOC001', day: 'Rabu',   startTime: '08:00', endTime: '12:00', quota: 20, isActive: true },
      { doctorId: 'DOC001', day: 'Jumat',  startTime: '13:00', endTime: '17:00', quota: 15, isActive: true },
      // Dr Sari - Anak
      { doctorId: 'DOC002', day: 'Selasa', startTime: '08:00', endTime: '12:00', quota: 20, isActive: true },
      { doctorId: 'DOC002', day: 'Kamis',  startTime: '08:00', endTime: '12:00', quota: 20, isActive: true },
      { doctorId: 'DOC002', day: 'Sabtu',  startTime: '08:00', endTime: '13:00', quota: 25, isActive: true },
      // Dr Hendra - Bedah
      { doctorId: 'DOC003', day: 'Senin',  startTime: '13:00', endTime: '17:00', quota: 15, isActive: true },
      { doctorId: 'DOC003', day: 'Kamis',  startTime: '13:00', endTime: '17:00', quota: 15, isActive: true },
      // Dr Maya - Kandungan
      { doctorId: 'DOC004', day: 'Selasa', startTime: '13:00', endTime: '17:00', quota: 15, isActive: true },
      { doctorId: 'DOC004', day: 'Jumat',  startTime: '08:00', endTime: '12:00', quota: 15, isActive: true },
      // Dr Rudi - Umum
      { doctorId: 'DOC005', day: 'Senin',  startTime: '07:00', endTime: '14:00', quota: 40, isActive: true },
      { doctorId: 'DOC005', day: 'Selasa', startTime: '07:00', endTime: '14:00', quota: 40, isActive: true },
      { doctorId: 'DOC005', day: 'Rabu',   startTime: '07:00', endTime: '14:00', quota: 40, isActive: true },
      { doctorId: 'DOC005', day: 'Kamis',  startTime: '07:00', endTime: '14:00', quota: 40, isActive: true },
      { doctorId: 'DOC005', day: 'Jumat',  startTime: '07:00', endTime: '14:00', quota: 40, isActive: true },
      { doctorId: 'DOC005', day: 'Sabtu',  startTime: '07:00', endTime: '12:00', quota: 30, isActive: true },
    ];
    scheds.forEach((s, i) => DB.insert('schedules', { ...s, id: `SCH${String(i+1).padStart(3,'0')}` }));
  },

  patients() {
    const patients = [
      { id: 'PAT001', nik: '3271010101800001', name: 'Budi Santoso', birthDate: '1980-01-01', gender: 'L', address: 'Jl. Merdeka No. 10, Jakarta Barat', phone: '081111111111', bloodType: 'A', insurance: 'BPJS', insuranceNo: '0001234567890', email: 'budi@email.com', maritalStatus: 'Menikah', job: 'Pegawai Swasta' },
      { id: 'PAT002', nik: '3271015505920002', name: 'Siti Rahayu', birthDate: '1992-05-15', gender: 'P', address: 'Jl. Sudirman No. 25, Bandung', phone: '082222222222', bloodType: 'B', insurance: 'BPJS', insuranceNo: '0001234567891', email: 'siti@email.com', maritalStatus: 'Menikah', job: 'Ibu Rumah Tangga' },
      { id: 'PAT003', nik: '3271011212750003', name: 'Ahmad Hidayat', birthDate: '1975-12-12', gender: 'L', address: 'Jl. Diponegoro No. 5, Surabaya', phone: '083333333333', bloodType: 'O', insurance: 'Mandiri', insuranceNo: '', email: '', maritalStatus: 'Menikah', job: 'Wiraswasta' },
      { id: 'PAT004', nik: '3271010303880004', name: 'Dewi Lestari', birthDate: '1988-03-03', gender: 'P', address: 'Jl. Gatot Subroto No. 15, Jakarta Selatan', phone: '084444444444', bloodType: 'AB', insurance: 'BPJS', insuranceNo: '0001234567892', email: 'dewi@email.com', maritalStatus: 'Belum Menikah', job: 'Karyawan BUMN' },
      { id: 'PAT005', nik: '3271012020650005', name: 'Rudi Hermawan', birthDate: '1965-02-20', gender: 'L', address: 'Jl. Ahmad Yani No. 50, Bekasi', phone: '085555555555', bloodType: 'A', insurance: 'Pensiunan', insuranceNo: '0001234567893', email: '', maritalStatus: 'Menikah', job: 'Pensiunan PNS' },
      { id: 'PAT006', nik: '3271010707980006', name: 'Fitri Handayani', birthDate: '1998-07-07', gender: 'P', address: 'Jl. Kebon Jeruk No. 8, Jakarta Barat', phone: '086666666666', bloodType: 'O', insurance: 'Mandiri', insuranceNo: '', email: 'fitri@email.com', maritalStatus: 'Belum Menikah', job: 'Mahasiswa' },
      { id: 'PAT007', nik: '3271011515720007', name: 'Agus Prasetyo', birthDate: '1972-05-15', gender: 'L', address: 'Jl. Cempaka Putih No. 30, Jakarta Pusat', phone: '087777777777', bloodType: 'B', insurance: 'BPJS', insuranceNo: '0001234567894', email: 'agus@email.com', maritalStatus: 'Menikah', job: 'PNS' },
      { id: 'PAT008', nik: '3271012525900008', name: 'Nurul Aisyah', birthDate: '1990-05-25', gender: 'P', address: 'Jl. Tebet Barat No. 12, Jakarta Selatan', phone: '088888888888', bloodType: 'A', insurance: 'Asuransi Jiwa', insuranceNo: 'AJ001234', email: 'nurul@email.com', maritalStatus: 'Menikah', job: 'Dokter Gigi' },
      { id: 'PAT009', nik: '3271010101850009', name: 'Hendra Gunawan', birthDate: '1985-01-01', gender: 'L', address: 'Jl. Pluit Raya No. 5, Jakarta Utara', phone: '089999999999', bloodType: 'O', insurance: 'BPJS', insuranceNo: '0001234567895', email: '', maritalStatus: 'Menikah', job: 'Pedagang' },
      { id: 'PAT010', nik: '3271011818020010', name: 'Anisa Putri', birthDate: '2002-08-18', gender: 'P', address: 'Jl. Kelapa Gading No. 20, Jakarta Utara', phone: '080000000000', bloodType: 'B', insurance: 'Mandiri', insuranceNo: '', email: 'anisa@email.com', maritalStatus: 'Belum Menikah', job: 'Pelajar' },
      { id: 'PAT011', nik: '3271010910680011', name: 'Wahyu Setiawan', birthDate: '1968-10-09', gender: 'L', address: 'Jl. Kemang Raya No. 88, Jakarta Selatan', phone: '081500000011', bloodType: 'AB', insurance: 'BPJS', insuranceNo: '0001234567896', email: '', maritalStatus: 'Menikah', job: 'Pensiunan TNI' },
      { id: 'PAT012', nik: '3271012003950012', name: 'Ratna Sari', birthDate: '1995-03-20', gender: 'P', address: 'Jl. Pasar Minggu No. 15, Jakarta Selatan', phone: '081500000012', bloodType: 'A', insurance: 'BPJS', insuranceNo: '0001234567897', email: 'ratna@email.com', maritalStatus: 'Belum Menikah', job: 'Karyawan Swasta' },
    ];
    patients.forEach(p => DB.insert('patients', p));
  },

  medications() {
    const meds = [
      { id: 'MED001', name: 'Paracetamol 500mg', genericName: 'Paracetamol', category: 'Analgesik/Antipiretik', unit: 'Tablet', stock: 500, minStock: 50, price: 500, expiryDate: '2026-06-30', manufacturer: 'Kimia Farma' },
      { id: 'MED002', name: 'Amoxicillin 500mg', genericName: 'Amoxicillin', category: 'Antibiotik', unit: 'Kapsul', stock: 200, minStock: 30, price: 3500, expiryDate: '2026-03-31', manufacturer: 'Dexa Medica' },
      { id: 'MED003', name: 'Omeprazole 20mg', genericName: 'Omeprazole', category: 'Lambung', unit: 'Kapsul', stock: 150, minStock: 20, price: 4000, expiryDate: '2026-09-30', manufacturer: 'Mersi Farma' },
      { id: 'MED004', name: 'Metformin 500mg', genericName: 'Metformin HCl', category: 'Antidiabetik', unit: 'Tablet', stock: 300, minStock: 50, price: 1500, expiryDate: '2026-12-31', manufacturer: 'Kimia Farma' },
      { id: 'MED005', name: 'Amlodipine 5mg', genericName: 'Amlodipine Besylate', category: 'Antihipertensi', unit: 'Tablet', stock: 250, minStock: 40, price: 2000, expiryDate: '2026-08-31', manufacturer: 'Pfizer' },
      { id: 'MED006', name: 'Cetirizine 10mg', genericName: 'Cetirizine HCl', category: 'Antihistamin', unit: 'Tablet', stock: 180, minStock: 25, price: 2500, expiryDate: '2026-07-31', manufacturer: 'Dexa Medica' },
      { id: 'MED007', name: 'Lansoprazole 30mg', genericName: 'Lansoprazole', category: 'Lambung', unit: 'Kapsul', stock: 100, minStock: 20, price: 6000, expiryDate: '2026-05-31', manufacturer: 'Sanbe Farma' },
      { id: 'MED008', name: 'Simvastatin 20mg', genericName: 'Simvastatin', category: 'Kolesterol', unit: 'Tablet', stock: 200, minStock: 30, price: 3000, expiryDate: '2026-11-30', manufacturer: 'Kalbe Farma' },
      { id: 'MED009', name: 'Salbutamol 4mg', genericName: 'Salbutamol Sulfate', category: 'Bronkodilator', unit: 'Tablet', stock: 120, minStock: 20, price: 2000, expiryDate: '2026-10-31', manufacturer: 'GlaxoSmithKline' },
      { id: 'MED010', name: 'Vitamin C 500mg', genericName: 'Asam Askorbat', category: 'Vitamin', unit: 'Tablet', stock: 600, minStock: 100, price: 1000, expiryDate: '2027-01-31', manufacturer: 'Kimia Farma' },
      { id: 'MED011', name: 'Antasida Doen', genericName: 'Al(OH)3 + Mg(OH)2', category: 'Lambung', unit: 'Tablet', stock: 400, minStock: 50, price: 800, expiryDate: '2026-06-30', manufacturer: 'Kimia Farma' },
      { id: 'MED012', name: 'Ibuprofen 400mg', genericName: 'Ibuprofen', category: 'NSAID', unit: 'Tablet', stock: 300, minStock: 40, price: 1800, expiryDate: '2026-09-30', manufacturer: 'Dexa Medica' },
      { id: 'MED013', name: 'Dexamethasone 0.5mg', genericName: 'Dexamethasone', category: 'Kortikosteroid', unit: 'Tablet', stock: 80, minStock: 15, price: 1200, expiryDate: '2026-04-30', manufacturer: 'Kimia Farma' },
      { id: 'MED014', name: 'Ciprofloxacin 500mg', genericName: 'Ciprofloxacin HCl', category: 'Antibiotik', unit: 'Tablet', stock: 15, minStock: 30, price: 5000, expiryDate: '2026-08-31', manufacturer: 'Bayer' },
      { id: 'MED015', name: 'Loratadine 10mg', genericName: 'Loratadine', category: 'Antihistamin', unit: 'Tablet', stock: 150, minStock: 25, price: 3000, expiryDate: '2027-02-28', manufacturer: 'Sanbe Farma' },
      { id: 'MED016', name: 'Captopril 25mg', genericName: 'Captopril', category: 'Antihipertensi', unit: 'Tablet', stock: 200, minStock: 30, price: 1500, expiryDate: '2026-12-31', manufacturer: 'Kimia Farma' },
      { id: 'MED017', name: 'Codein 10mg', genericName: 'Codeine Phosphate', category: 'Antitusif', unit: 'Tablet', stock: 50, minStock: 10, price: 8000, expiryDate: '2026-06-30', manufacturer: 'Kimia Farma' },
      { id: 'MED018', name: 'Glibenclamide 5mg', genericName: 'Glibenclamide', category: 'Antidiabetik', unit: 'Tablet', stock: 180, minStock: 30, price: 1200, expiryDate: '2026-10-31', manufacturer: 'Merck' },
      { id: 'MED019', name: 'Ranitidine 150mg', genericName: 'Ranitidine HCl', category: 'Lambung', unit: 'Tablet', stock: 8, minStock: 20, price: 2500, expiryDate: '2025-12-31', manufacturer: 'Sanbe Farma' },
      { id: 'MED020', name: 'Vitamin B Complex', genericName: 'B1+B6+B12', category: 'Vitamin', unit: 'Tablet', stock: 400, minStock: 60, price: 1500, expiryDate: '2027-03-31', manufacturer: 'Kalbe Farma' },
      { id: 'MED021', name: 'NaCl 0.9% 500ml', genericName: 'Natrium Klorida', category: 'Cairan Infus', unit: 'Botol', stock: 60, minStock: 20, price: 25000, expiryDate: '2026-12-31', manufacturer: 'Otsuka' },
      { id: 'MED022', name: 'Ringer Laktat 500ml', genericName: 'Ringer Lactate', category: 'Cairan Infus', unit: 'Botol', stock: 45, minStock: 20, price: 28000, expiryDate: '2026-12-31', manufacturer: 'Otsuka' },
    ];
    meds.forEach(m => DB.insert('medications', m));
  },

  visits() {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const twoDaysAgo = new Date(Date.now() - 2*86400000).toISOString().split('T')[0];

    const visits = [
      { id: 'VIS001', patientId: 'PAT001', doctorId: 'DOC001', date: today, queueNo: 1, status: 'selesai', chiefComplaint: 'Sakit kepala dan demam 3 hari', registeredBy: 'USR001' },
      { id: 'VIS002', patientId: 'PAT002', doctorId: 'DOC002', date: today, queueNo: 2, status: 'selesai', chiefComplaint: 'Batuk pilek anak, demam 2 hari', registeredBy: 'USR001' },
      { id: 'VIS003', patientId: 'PAT003', doctorId: 'DOC001', date: today, queueNo: 3, status: 'dipanggil', chiefComplaint: 'Kontrol diabetes, gula darah naik', registeredBy: 'USR001' },
      { id: 'VIS004', patientId: 'PAT004', doctorId: 'DOC005', date: today, queueNo: 1, status: 'menunggu', chiefComplaint: 'Pusing berputar, mual', registeredBy: 'USR001' },
      { id: 'VIS005', patientId: 'PAT005', doctorId: 'DOC001', date: today, queueNo: 4, status: 'menunggu', chiefComplaint: 'Kontrol hipertensi rutin', registeredBy: 'USR001' },
      { id: 'VIS006', patientId: 'PAT006', doctorId: 'DOC005', date: today, queueNo: 2, status: 'menunggu', chiefComplaint: 'Nyeri perut bagian bawah', registeredBy: 'USR001' },
      { id: 'VIS007', patientId: 'PAT007', doctorId: 'DOC001', date: yesterday, queueNo: 1, status: 'selesai', chiefComplaint: 'Sesak napas, batuk kronis', registeredBy: 'USR001' },
      { id: 'VIS008', patientId: 'PAT008', doctorId: 'DOC004', date: yesterday, queueNo: 1, status: 'selesai', chiefComplaint: 'Kontrol kehamilan trimester 2', registeredBy: 'USR001' },
      { id: 'VIS009', patientId: 'PAT009', doctorId: 'DOC003', date: yesterday, queueNo: 1, status: 'selesai', chiefComplaint: 'Luka sayat tangan kanan', registeredBy: 'USR001' },
      { id: 'VIS010', patientId: 'PAT010', doctorId: 'DOC005', date: twoDaysAgo, queueNo: 1, status: 'selesai', chiefComplaint: 'Demam tinggi 3 hari, lemas', registeredBy: 'USR001' },
      { id: 'VIS011', patientId: 'PAT011', doctorId: 'DOC001', date: twoDaysAgo, queueNo: 2, status: 'selesai', chiefComplaint: 'Kontrol DM tipe 2', registeredBy: 'USR001' },
    ];
    visits.forEach(v => DB.insert('visits', v));
  },

  emr() {
    const emrRecords = [
      {
        id: 'EMR001', visitId: 'VIS001',
        vitalSigns: { sistol: 130, diastol: 85, nadi: 88, suhu: 38.5, rr: 20, bb: 70, tb: 170, spo2: 98 },
        subjective: 'Pasien mengeluh sakit kepala berdenyut dan demam sejak 3 hari yang lalu. Mual tanpa muntah. Nafsu makan menurun.',
        objective: 'Pasien tampak lemas, TD 130/85 mmHg, Nadi 88x/mnt, Suhu 38.5°C. Konjungtiva tidak anemis. Leher tidak ada pembesaran KGB.',
        assessment: 'Febris e.c suspek viral. Possible tension headache.',
        plan: 'Istirahat cukup, minum air putih banyak. Obat Paracetamol 3x1 tablet, Vitamin C 1x1 tablet. Kontrol 3 hari jika tidak membaik.',
        diagnosis: 'J11.1 - Influenza dengan manifestasi pernapasan lain, virus tidak teridentifikasi',
        secondaryDiagnosis: 'G44.2 - Tension-type headache',
        allergies: 'Tidak ada alergi diketahui',
        createdBy: 'USR002',
      },
      {
        id: 'EMR002', visitId: 'VIS002',
        vitalSigns: { sistol: 100, diastol: 65, nadi: 96, suhu: 38.8, rr: 24, bb: 18, tb: 110, spo2: 97 },
        subjective: 'Ibu pasien mengeluh anak batuk pilek dan demam 2 hari. Tidak mau makan. Rewel.',
        objective: 'Anak tampak rewel, faring hiperemis, tonsil T1-T1, tidak ada retraksi dinding dada. Suhu 38.8°C.',
        assessment: 'ISPA. Tonsilo-faringitis akut.',
        plan: 'Paracetamol sirup 3x1 cth, Amoxicillin sirup 3x1 cth, Vitamin C sirup 1x1 cth. Banyak minum air putih. Kontrol 3 hari.',
        diagnosis: 'J06.9 - Infeksi saluran napas atas akut, tidak spesifik',
        secondaryDiagnosis: 'J03.9 - Tonsilitis akut, tidak spesifik',
        allergies: 'Tidak ada alergi diketahui',
        createdBy: 'USR003',
      },
      {
        id: 'EMR007', visitId: 'VIS007',
        vitalSigns: { sistol: 145, diastol: 92, nadi: 84, suhu: 36.8, rr: 22, bb: 75, tb: 168, spo2: 95 },
        subjective: 'Pasien mengeluh sesak napas terutama saat aktivitas dan batuk berdahak berwarna kuning sejak 1 minggu. Ada riwayat merokok 20 tahun.',
        objective: 'Tampak sesak, ada penggunaan otot bantu napas ringan. Suara napas menurun di basal kiri. Ronkhi kasar bilateral.',
        assessment: 'PPOK eksaserbasi akut. Possible pneumonia.',
        plan: 'Salbutamol 3x1 tab, Dexamethasone 3x1 tab, Amoxicillin 3x1 kaps, Lansoprazole 1x1 kaps. Disarankan berhenti merokok. Rujuk poli paru jika tidak membaik 5 hari.',
        diagnosis: 'J44.1 - PPOK dengan eksaserbasi akut',
        secondaryDiagnosis: '',
        allergies: 'Penisilin (ruam)',
        createdBy: 'USR002',
      },
    ];
    emrRecords.forEach(e => DB.insert('emr', e));
  },

  prescriptions() {
    const rxs = [
      {
        id: 'RX001', emrId: 'EMR001', visitId: 'VIS001',
        medications: [
          { medicationId: 'MED001', name: 'Paracetamol 500mg', qty: 10, unit: 'Tablet', dose: '500mg', frequency: '3x sehari', notes: 'Sesudah makan' },
          { medicationId: 'MED010', name: 'Vitamin C 500mg', qty: 7, unit: 'Tablet', dose: '500mg', frequency: '1x sehari', notes: 'Pagi hari' },
        ],
        status: 'diserahkan',
        dispensedBy: 'USR005',
        dispensedAt: new Date().toISOString(),
        notes: '',
        createdBy: 'USR002',
      },
      {
        id: 'RX002', emrId: 'EMR002', visitId: 'VIS002',
        medications: [
          { medicationId: 'MED001', name: 'Paracetamol 500mg', qty: 15, unit: 'Tablet', dose: '250mg', frequency: '3x sehari', notes: 'Jika demam > 38°C' },
          { medicationId: 'MED002', name: 'Amoxicillin 500mg', qty: 14, unit: 'Kapsul', dose: '250mg', frequency: '2x sehari', notes: 'Sesudah makan, habiskan' },
          { medicationId: 'MED010', name: 'Vitamin C 500mg', qty: 7, unit: 'Tablet', dose: '250mg', frequency: '1x sehari', notes: '' },
        ],
        status: 'diserahkan',
        dispensedBy: 'USR005',
        dispensedAt: new Date().toISOString(),
        notes: '',
        createdBy: 'USR003',
      },
      {
        id: 'RX007', emrId: 'EMR007', visitId: 'VIS007',
        medications: [
          { medicationId: 'MED009', name: 'Salbutamol 4mg', qty: 10, unit: 'Tablet', dose: '4mg', frequency: '3x sehari', notes: '' },
          { medicationId: 'MED013', name: 'Dexamethasone 0.5mg', qty: 9, unit: 'Tablet', dose: '0.5mg', frequency: '3x sehari', notes: 'Sesudah makan' },
          { medicationId: 'MED002', name: 'Amoxicillin 500mg', qty: 15, unit: 'Kapsul', dose: '500mg', frequency: '3x sehari', notes: 'Sesudah makan, habiskan' },
          { medicationId: 'MED007', name: 'Lansoprazole 30mg', qty: 7, unit: 'Kapsul', dose: '30mg', frequency: '1x sehari', notes: 'Sebelum makan pagi' },
        ],
        status: 'menunggu',
        dispensedBy: null,
        dispensedAt: null,
        notes: 'Hati-hati alergi penisilin, sudah diganti Amoxicillin',
        createdBy: 'USR002',
      },
    ];
    rxs.forEach(r => DB.insert('prescriptions', r));
  },

  labOrders() {
    const orders = [
      {
        id: 'LAB001', visitId: 'VIS001',
        tests: [
          { code: 'DL', name: 'Darah Lengkap (CBC)' },
          { code: 'WID', name: 'Widal Test' },
        ],
        status: 'selesai',
        requestedBy: 'USR002',
        requestedAt: new Date(Date.now() - 7200000).toISOString(),
        results: [
          { test: 'Hemoglobin', value: '13.5', unit: 'g/dL', normalRange: '12-16 g/dL', flag: 'N' },
          { test: 'Leukosit', value: '11200', unit: '/µL', normalRange: '4000-10000 /µL', flag: 'H' },
          { test: 'Trombosit', value: '280000', unit: '/µL', normalRange: '150000-400000 /µL', flag: 'N' },
          { test: 'Hematokrit', value: '41', unit: '%', normalRange: '37-47 %', flag: 'N' },
          { test: 'Widal O', value: '1/160', unit: '', normalRange: '< 1/80', flag: 'H' },
          { test: 'Widal H', value: '1/80', unit: '', normalRange: '< 1/80', flag: 'N' },
        ],
        resultAt: new Date(Date.now() - 3600000).toISOString(),
        resultBy: 'USR007',
        notes: 'Leukositosis dan Widal positif, kemungkinan infeksi tifoid.',
      },
      {
        id: 'LAB002', visitId: 'VIS003',
        tests: [
          { code: 'GDS', name: 'Gula Darah Sewaktu' },
          { code: 'GDP', name: 'Gula Darah Puasa' },
          { code: 'HbA1c', name: 'HbA1c' },
        ],
        status: 'proses',
        requestedBy: 'USR002',
        requestedAt: new Date(Date.now() - 1800000).toISOString(),
        results: [],
        resultAt: null,
        resultBy: null,
        notes: '',
      },
      {
        id: 'LAB003', visitId: 'VIS010',
        tests: [
          { code: 'DL', name: 'Darah Lengkap (CBC)' },
          { code: 'NS1', name: 'Antigen NS1 Dengue' },
          { code: 'IGMD', name: 'IgM/IgG Dengue' },
        ],
        status: 'selesai',
        requestedBy: 'USR004',
        requestedAt: new Date(Date.now() - 172800000).toISOString(),
        results: [
          { test: 'Hemoglobin', value: '12.8', unit: 'g/dL', normalRange: '11.5-16 g/dL', flag: 'N' },
          { test: 'Leukosit', value: '3200', unit: '/µL', normalRange: '4000-10000 /µL', flag: 'L' },
          { test: 'Trombosit', value: '98000', unit: '/µL', normalRange: '150000-400000 /µL', flag: 'L' },
          { test: 'Hematokrit', value: '45', unit: '%', normalRange: '37-47 %', flag: 'N' },
          { test: 'NS1 Antigen', value: 'Reaktif', unit: '', normalRange: 'Non-Reaktif', flag: 'H' },
          { test: 'IgM Dengue', value: 'Non-Reaktif', unit: '', normalRange: 'Non-Reaktif', flag: 'N' },
          { test: 'IgG Dengue', value: 'Reaktif', unit: '', normalRange: 'Non-Reaktif', flag: 'H' },
        ],
        resultAt: new Date(Date.now() - 165600000).toISOString(),
        resultBy: 'USR007',
        notes: 'NS1 positif, kesan Demam Dengue.',
      },
    ];
    orders.forEach(o => DB.insert('labOrders', o));
  },

  payments() {
    const pays = [
      {
        id: 'PAY001', visitId: 'VIS001',
        items: [
          { name: 'Biaya Konsultasi - dr. Ahmad Fauzi, Sp.PD', qty: 1, price: 150000 },
          { name: 'Paracetamol 500mg (10 tab)', qty: 1, price: 5000 },
          { name: 'Vitamin C 500mg (7 tab)', qty: 1, price: 7000 },
          { name: 'Pemeriksaan Darah Lengkap', qty: 1, price: 75000 },
          { name: 'Pemeriksaan Widal Test', qty: 1, price: 50000 },
        ],
        subtotal: 287000, discount: 0, adminFee: 15000, total: 302000,
        method: 'BPJS', insuranceNo: '0001234567890', insuranceCover: 287000, patientPay: 15000,
        status: 'lunas', paidAt: new Date().toISOString(), paidBy: 'USR006',
        notes: '',
      },
      {
        id: 'PAY002', visitId: 'VIS002',
        items: [
          { name: 'Biaya Konsultasi - dr. Sari Dewi, Sp.A', qty: 1, price: 150000 },
          { name: 'Paracetamol 500mg (15 tab)', qty: 1, price: 7500 },
          { name: 'Amoxicillin 500mg (14 kaps)', qty: 1, price: 49000 },
          { name: 'Vitamin C 500mg (7 tab)', qty: 1, price: 7000 },
        ],
        subtotal: 213500, discount: 0, adminFee: 0, total: 213500,
        method: 'BPJS', insuranceNo: '0001234567891', insuranceCover: 213500, patientPay: 0,
        status: 'lunas', paidAt: new Date().toISOString(), paidBy: 'USR006',
        notes: '',
      },
    ];
    pays.forEach(p => DB.insert('payments', p));
  },

  queues() {
    const today = new Date().toISOString().split('T')[0];
    const queues = [
      { id: 'QUE001', visitId: 'VIS001', doctorId: 'DOC001', queueNo: 1, status: 'selesai', date: today, calledAt: new Date(Date.now()-7200000).toISOString(), completedAt: new Date(Date.now()-6000000).toISOString() },
      { id: 'QUE002', visitId: 'VIS002', doctorId: 'DOC002', queueNo: 2, status: 'selesai', date: today, calledAt: new Date(Date.now()-5400000).toISOString(), completedAt: new Date(Date.now()-4800000).toISOString() },
      { id: 'QUE003', visitId: 'VIS003', doctorId: 'DOC001', queueNo: 3, status: 'dipanggil', date: today, calledAt: new Date(Date.now()-1800000).toISOString(), completedAt: null },
      { id: 'QUE004', visitId: 'VIS004', doctorId: 'DOC005', queueNo: 1, status: 'menunggu', date: today, calledAt: null, completedAt: null },
      { id: 'QUE005', visitId: 'VIS005', doctorId: 'DOC001', queueNo: 4, status: 'menunggu', date: today, calledAt: null, completedAt: null },
      { id: 'QUE006', visitId: 'VIS006', doctorId: 'DOC005', queueNo: 2, status: 'menunggu', date: today, calledAt: null, completedAt: null },
    ];
    queues.forEach(q => DB.insert('queues', q));
  },
};
