/**
 * SIMRS RS Rakyat Sejahterah
 * Core Application — Auth, Routing, Nav, Toast, Modal
 */

const App = {
  user: null,
  currentModule: 'dashboard',
  sidebarCollapsed: false,

  NAV: [
    { id: 'dashboard',   icon: 'layout-dashboard', label: 'Dashboard',       roles: ['admin','dokter','apoteker','kasir','lab'] },
    { id: 'patients',    icon: 'users',             label: 'Data Pasien',     roles: ['admin','dokter'], section: 'Klinik' },
    { id: 'scheduling',  icon: 'calendar-clock',    label: 'Jadwal & Antrian',roles: ['admin','dokter'], section: null },
    { id: 'emr',         icon: 'file-text',         label: 'Rekam Medis',     roles: ['admin','dokter'], section: null },
    { id: 'pharmacy',    icon: 'pill',              label: 'Farmasi',         roles: ['admin','apoteker'], section: 'Layanan' },
    { id: 'billing',     icon: 'receipt',           label: 'Billing',         roles: ['admin','kasir'], section: null },
    { id: 'laboratory',  icon: 'microscope',        label: 'Laboratorium',    roles: ['admin','lab'], section: null },
    { id: 'users',       icon: 'shield-check',      label: 'Pengguna',        roles: ['admin'], section: 'Sistem' },
    { id: 'reports',     icon: 'bar-chart-2',       label: 'Laporan',         roles: ['admin'], section: null },
  ],

  ROLE_COLORS: {
    admin: 'blue', dokter: 'green', apoteker: 'purple',
    kasir: 'amber', lab: 'teal'
  },

  ROLE_LABELS: {
    admin: 'Administrator', dokter: 'Dokter', apoteker: 'Apoteker',
    kasir: 'Kasir', lab: 'Analis Lab'
  },

  init() {
    // Check session
    const saved = sessionStorage.getItem('simrs_user');
    if (!saved) { window.location.href = 'index.html'; return; }
    this.user = JSON.parse(saved);

    // Init seed
    Seed.init();

    // Render layout
    this.renderSidebar();
    this.renderTopbar();

    // Route
    const hash = location.hash.replace('#', '') || 'dashboard';
    this.navigate(hash);

    // Hash change
    window.addEventListener('hashchange', () => {
      const mod = location.hash.replace('#', '') || 'dashboard';
      this.navigate(mod);
    });

    // Click outside dropdown
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.dropdown')) {
        document.querySelectorAll('.dropdown-menu.open').forEach(m => m.classList.remove('open'));
      }
    });

    // Sidebar overlay click
    document.getElementById('sidebarOverlay')?.addEventListener('click', () => this.closeMobileSidebar());
  },

  navigate(moduleId) {
    // Validate access
    const navItem = this.NAV.find(n => n.id === moduleId);
    if (navItem && !navItem.roles.includes(this.user.role)) {
      moduleId = 'dashboard';
    }

    this.currentModule = moduleId;
    location.hash = moduleId;

    // Update active nav
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.module === moduleId);
    });

    // Update topbar title
    const navFound = this.NAV.find(n => n.id === moduleId);
    const title = navFound ? navFound.label : 'Dashboard';
    const titleEl = document.getElementById('pageTitle');
    const subtitleEl = document.getElementById('pageBreadcrumb');
    if (titleEl) titleEl.textContent = title;
    if (subtitleEl) subtitleEl.textContent = `RS Rakyat Sejahterah › ${title}`;

    // Render module
    const content = document.getElementById('content-area');
    content.innerHTML = `<div class="loading-overlay"><div class="spinner"></div><span>Memuat...</span></div>`;

    setTimeout(() => {
      const mods = {
        dashboard: Modules.Dashboard,
        patients: Modules.Patients,
        scheduling: Modules.Scheduling,
        emr: Modules.EMR,
        pharmacy: Modules.Pharmacy,
        billing: Modules.Billing,
        laboratory: Modules.Laboratory,
        users: Modules.Users,
        reports: Modules.Reports,
      };
      const mod = mods[moduleId];
      if (mod) {
        content.innerHTML = '';
        mod.render(content);
      } else {
        content.innerHTML = `<div class="empty-state"><div class="empty-state-icon">${this.icon('construction', 48)}</div><h4>Modul belum tersedia</h4><p>Fitur ini sedang dalam pengembangan.</p></div>`;
      }
    }, 150);

    // Close mobile sidebar
    this.closeMobileSidebar();
  },

  renderSidebar() {
    const sidebar = document.getElementById('sidebar');
    const userNav = this.NAV.filter(n => n.roles.includes(this.user.role));
    const avatarColor = this.ROLE_COLORS[this.user.role] || 'blue';
    const initials = this.user.name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();

    // Build nav items grouped by section
    let navHTML = '';
    let lastSection = '';
    userNav.forEach(item => {
      if (item.section && item.section !== lastSection) {
        navHTML += `<div class="nav-section-label">${item.section}</div>`;
        lastSection = item.section;
      } else if (!item.section && item.id === 'dashboard') {
        lastSection = '';
      }
      navHTML += `
        <div class="nav-item" data-module="${item.id}" onclick="App.navigate('${item.id}')" title="${item.label}">
          ${this.icon(item.icon, 19, 'nav-icon')}
          <span class="nav-label">${item.label}</span>
        </div>
      `;
    });

    sidebar.innerHTML = `
      <div class="sidebar-logo">
        <div class="sidebar-logo-icon">
          ${this.icon('cross', 22, '', 'color:#fff;stroke-width:2.5')}
        </div>
        <div class="sidebar-logo-text">
          <h1>RS Rakyat Sejahterah</h1>
          <p>SIMRS v1.0</p>
        </div>
      </div>

      <nav class="sidebar-nav">
        ${navHTML}
      </nav>

      <div class="sidebar-footer">
        <div class="sidebar-user" onclick="App.toggleUserMenu()">
          <div class="user-avatar avatar-${avatarColor}">${initials}</div>
          <div class="sidebar-user-info">
            <div class="user-name-sidebar">${this.user.name}</div>
            <div class="user-role-sidebar">${this.ROLE_LABELS[this.user.role]}</div>
          </div>
          <button class="sidebar-logout-btn" onclick="event.stopPropagation(); App.logout()" title="Keluar">
            ${this.icon('log-out', 15)}
          </button>
        </div>
      </div>
    `;
  },

  renderTopbar() {
    const topbar = document.getElementById('topbar');
    const initials = this.user.name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
    const avatarColor = this.ROLE_COLORS[this.user.role] || 'blue';
    const now = new Date();
    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

    topbar.innerHTML = `
      <button class="topbar-toggle" onclick="App.toggleSidebar()" title="Toggle Sidebar">
        ${this.icon('menu', 18)}
      </button>

      <div class="topbar-page-info">
        <div class="topbar-page-title" id="pageTitle">Dashboard</div>
        <div class="topbar-breadcrumb-text" id="pageBreadcrumb">RS Rakyat Sejahterah › Dashboard</div>
      </div>

      <div class="topbar-actions">
        <div style="font-size:11px;color:var(--text-muted);text-align:right;line-height:1.4">
          <div style="font-weight:600;color:var(--text-secondary)">${timeStr}</div>
          <div>${dateStr}</div>
        </div>

        <div class="topbar-divider"></div>

        <button class="topbar-icon-btn" title="Notifikasi">
          ${this.icon('bell', 17)}
          <div class="notification-dot"></div>
        </button>

        <div class="dropdown">
          <button class="topbar-user-btn" onclick="this.closest('.dropdown').querySelector('.dropdown-menu').classList.toggle('open')">
            <div class="user-avatar avatar-sm avatar-${avatarColor}">${initials}</div>
            <div style="text-align:left">
              <div class="topbar-user-name">${this.user.name.split(' ').slice(0,2).join(' ')}</div>
              <div class="topbar-user-role">${this.ROLE_LABELS[this.user.role]}</div>
            </div>
            ${this.icon('chevron-down', 13, '', 'color:var(--text-muted)')}
          </button>
          <div class="dropdown-menu" style="min-width:200px">
            <div class="dropdown-item" onclick="App.navigate('users')">
              ${this.icon('user', 15)}Profil Saya
            </div>
            <div class="dropdown-divider"></div>
            <div class="dropdown-item danger" onclick="App.logout()">
              ${this.icon('log-out', 15)}Keluar
            </div>
          </div>
        </div>
      </div>
    `;
  },

  toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const wrapper = document.getElementById('mainWrapper');
    const isMobile = window.innerWidth <= 768;

    if (isMobile) {
      sidebar.classList.toggle('mobile-open');
      document.getElementById('sidebarOverlay')?.classList.toggle('active');
    } else {
      this.sidebarCollapsed = !this.sidebarCollapsed;
      sidebar.classList.toggle('collapsed', this.sidebarCollapsed);
      wrapper.classList.toggle('expanded', this.sidebarCollapsed);
    }
  },

  closeMobileSidebar() {
    document.getElementById('sidebar')?.classList.remove('mobile-open');
    document.getElementById('sidebarOverlay')?.classList.remove('active');
  },

  logout() {
    sessionStorage.removeItem('simrs_user');
    window.location.href = 'index.html';
  },

  // === TOAST SYSTEM ===
  toast(message, type = 'success', title = null, duration = 3500) {
    const icons = {
      success: `<circle cx="12" cy="12" r="10"/><polyline points="9 12 11 14 15 10"/>`,
      error:   `<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>`,
      warning: `<path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>`,
      info:    `<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>`,
    };
    const defaultTitles = { success: 'Berhasil', error: 'Error', warning: 'Peringatan', info: 'Info' };

    const container = document.getElementById('toast-container');
    const id = 'toast-' + Date.now();
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.id = id;
    el.innerHTML = `
      <svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${icons[type] || icons.info}</svg>
      <div class="toast-content">
        <div class="toast-title">${title || defaultTitles[type]}</div>
        <div class="toast-message">${message}</div>
      </div>
      <button class="toast-dismiss" onclick="App.dismissToast('${id}')">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    `;
    container.appendChild(el);
    setTimeout(() => this.dismissToast(id), duration);
  },

  dismissToast(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.add('dismissing');
    setTimeout(() => el.remove(), 300);
  },

  // === MODAL SYSTEM ===
  modal({ title, subtitle = '', body, footer = null, size = '', onClose = null }) {
    const backdrop = document.getElementById('modal-backdrop');
    backdrop.innerHTML = `
      <div class="modal ${size}" role="dialog" aria-modal="true">
        <div class="modal-header">
          <div>
            <div class="modal-title">${title}</div>
            ${subtitle ? `<div class="modal-subtitle">${subtitle}</div>` : ''}
          </div>
          <button class="modal-close" onclick="App.closeModal()" title="Tutup">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <div class="modal-body">${body}</div>
        ${footer ? `<div class="modal-footer">${footer}</div>` : ''}
      </div>
    `;
    backdrop.classList.add('active');
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) { if (onClose) onClose(); this.closeModal(); }
    }, { once: true });
  },

  closeModal() {
    const backdrop = document.getElementById('modal-backdrop');
    backdrop.classList.remove('active');
    backdrop.innerHTML = '';
  },

  confirm({ title, message, confirmLabel = 'Ya, Lanjutkan', confirmClass = 'btn-danger', onConfirm }) {
    this.modal({
      title,
      body: `<p style="font-size:14px;color:var(--text-secondary);line-height:1.6">${message}</p>`,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn ${confirmClass}" onclick="App.closeModal(); (${onConfirm.toString()})()">
          ${confirmLabel}
        </button>
      `,
      size: 'modal-sm',
    });
  },

  // === ICONS (Lucide SVG) ===
  icon(name, size = 18, cls = '', style = '') {
    const icons = {
      'layout-dashboard': `<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>`,
      'users': `<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>`,
      'calendar-clock': `<path d="M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h5"/><circle cx="17.5" cy="17.5" r="5.5"/><path d="M17.5 15.5v2l1.5 1.5"/>`,
      'file-text': `<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>`,
      'pill': `<path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/>`,
      'receipt': `<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8H8"/><path d="M16 12H8"/><path d="M12 16H8"/>`,
      'microscope': `<path d="M6 18h8"/><path d="M3 21h18"/><path d="M14 21v-4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v4"/><path d="M3 7h2"/><path d="M5 5h2v6H5z"/><path d="M12 5h2v6h-2z"/><path d="M14 7h6"/>`,
      'shield-check': `<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/>`,
      'bar-chart-2': `<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>`,
      'log-out': `<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>`,
      'menu': `<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>`,
      'bell': `<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>`,
      'chevron-down': `<polyline points="6 9 12 15 18 9"/>`,
      'chevron-right': `<polyline points="9 18 15 12 9 6"/>`,
      'user': `<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>`,
      'cross': `<path d="M11 2a2 2 0 0 0-2 2v5H4a2 2 0 0 0-2 2v2c0 1.1.9 2 2 2h5v5c0 1.1.9 2 2 2h2a2 2 0 0 0 2-2v-5h5a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2h-5V4a2 2 0 0 0-2-2h-2z"/>`,
      'plus': `<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>`,
      'search': `<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>`,
      'edit': `<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>`,
      'trash': `<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>`,
      'eye': `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`,
      'x': `<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>`,
      'check': `<polyline points="20 6 9 17 4 12"/>`,
      'check-circle': `<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>`,
      'alert-circle': `<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>`,
      'info': `<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>`,
      'filter': `<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>`,
      'download': `<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>`,
      'printer': `<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>`,
      'refresh-cw': `<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>`,
      'construction': `<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M17 12h.01"/><path d="M12 12h.01"/><path d="M7 12h.01"/>`,
      'activity': `<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>`,
      'clock': `<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>`,
      'hash': `<line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/>`,
      'package': `<line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>`,
      'trending-up': `<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>`,
      'trending-down': `<polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>`,
      'calendar': `<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>`,
      'map-pin': `<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>`,
      'phone': `<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.42 2 2 0 0 1 3.58 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.4a16 16 0 0 0 6.72 6.72l.91-.92a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>`,
      'mail': `<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22 6 12 13 2 6"/>`,
      'award': `<circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>`,
      'flask': `<path d="M9 3h6v13a3 3 0 0 1-3 3 3 3 0 0 1-3-3z"/><path d="M6.5 2h11"/>`,
      'clipboard': `<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/>`,
      'credit-card': `<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>`,
      'wallet': `<path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4"/><path d="M4 6v12c0 1.1.9 2 2 2h14v-4"/><circle cx="18" cy="12" r="2"/>`,
      'arrow-left': `<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>`,
      'arrow-right': `<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>`,
      'more-vertical': `<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>`,
      'star': `<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>`,
      'settings': `<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>`,
      'lock': `<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>`,
      'unlock': `<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>`,
      'clipboard-list': `<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M9 12h6"/><path d="M9 16h4"/>`,
      'test-tube': `<path d="M14.5 2 20 7.5l-11 11L3 13z"/><path d="m7.5 7.5 4 4"/><path d="m3 13 4.5 4.5L3 22l4.5-4.5"/>`,
      'alert-triangle': `<path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>`,
      'save': `<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>`,
      'send': `<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>`,
      'file-plus': `<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/>`,
      'user-plus': `<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/>`,
      'key': `<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>`,
      'percent': `<line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>`,
      'layers': `<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>`,
      'box': `<path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>`,
    };

    const d = icons[name] || `<circle cx="12" cy="12" r="4"/>`;
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" class="${cls}" style="${style}">${d}</svg>`;
  },

  // === HELPERS ===
  fmt: {
    date(iso) {
      if (!iso) return '-';
      return new Date(iso).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
    },
    dateShort(iso) {
      if (!iso) return '-';
      return new Date(iso).toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' });
    },
    time(iso) {
      if (!iso) return '-';
      return new Date(iso).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    },
    datetime(iso) {
      if (!iso) return '-';
      return new Date(iso).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    },
    currency(amount) {
      return 'Rp ' + Number(amount || 0).toLocaleString('id-ID');
    },
    age(birthDate) {
      if (!birthDate) return '-';
      const diff = Date.now() - new Date(birthDate).getTime();
      return Math.floor(diff / (365.25 * 24 * 60 * 60 * 1000)) + ' th';
    },
    genderLabel(g) { return g === 'L' ? 'Laki-laki' : 'Perempuan'; },
    initials(name) {
      return (name || '').split(' ').slice(0,2).map(w => w[0]).join('').toUpperCase();
    }
  },

  statusBadge(status) {
    const map = {
      'menunggu':   ['badge-warning', 'Menunggu'],
      'dipanggil':  ['badge-info', 'Dipanggil'],
      'selesai':    ['badge-success', 'Selesai'],
      'batal':      ['badge-neutral', 'Dibatalkan'],
      'pending':    ['badge-warning', 'Pending'],
      'proses':     ['badge-info', 'Diproses'],
      'diserahkan': ['badge-success', 'Diserahkan'],
      'lunas':      ['badge-success', 'Lunas'],
      'belum_bayar':['badge-danger', 'Belum Bayar'],
      'aktif':      ['badge-success', 'Aktif'],
      'nonaktif':   ['badge-neutral', 'Nonaktif'],
    };
    const [cls, label] = map[status] || ['badge-neutral', status];
    return `<span class="badge badge-status ${cls}">${label}</span>`;
  },

  avatarColor(name) {
    const colors = ['blue','green','purple','orange','rose','teal','amber','sky'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash += name.charCodeAt(i);
    return colors[hash % colors.length];
  },
};

// === REPORTS MODULE ===
// (Modules namespace initialized in dashboard.html before module scripts)
// Reports module (simple)
Modules.Reports = {
  render(container) {
    const visits = DB.get('visits');
    const payments = DB.get('payments');
    const totalRevenue = payments.filter(p => p.status === 'lunas').reduce((s, p) => s + (p.total || 0), 0);

    // Monthly stats
    const monthlyData = {};
    visits.forEach(v => {
      const month = v.date ? v.date.slice(0,7) : 'unknown';
      monthlyData[month] = (monthlyData[month] || 0) + 1;
    });

    container.innerHTML = `
      <div class="page-header">
        <div>
          <h2>Laporan & Statistik</h2>
          <p>Ringkasan data operasional rumah sakit</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-secondary btn-sm">${App.icon('download',14)} Export</button>
          <button class="btn btn-primary btn-sm">${App.icon('printer',14)} Cetak</button>
        </div>
      </div>

      <div class="stats-grid stagger fade-up">
        <div class="stat-card">
          <div class="stat-icon" style="background:var(--primary-subtle);">${App.icon('users', 24, '', 'color:var(--primary)')}</div>
          <div class="stat-body"><h3>${DB.count('patients')}</h3><p>Total Pasien Terdaftar</p></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:var(--success-subtle);">${App.icon('calendar', 24, '', 'color:var(--success)')}</div>
          <div class="stat-body"><h3>${visits.length}</h3><p>Total Kunjungan</p></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:var(--warning-subtle);">${App.icon('receipt', 24, '', 'color:var(--warning)')}</div>
          <div class="stat-body"><h3>${App.fmt.currency(totalRevenue)}</h3><p>Total Pendapatan</p></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:var(--purple-subtle);">${App.icon('microscope', 24, '', 'color:var(--purple)')}</div>
          <div class="stat-body"><h3>${DB.count('labOrders')}</h3><p>Pemeriksaan Lab</p></div>
        </div>
      </div>

      <div class="grid-2" style="gap:16px">
        <div class="card">
          <div class="card-header"><span class="card-title">${App.icon('bar-chart-2',16)} Kunjungan per Bulan</span></div>
          <div class="card-body"><div class="chart-container"><canvas id="chartVisits"></canvas></div></div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title">${App.icon('pie-chart',16)} Distribusi Metode Bayar</span></div>
          <div class="card-body"><div class="chart-container"><canvas id="chartPayment"></canvas></div></div>
        </div>
      </div>
    `;

    // Charts
    if (window.Chart) this._drawCharts(monthlyData, payments);
  },

  _drawCharts(monthlyData, payments) {
    const months = Object.keys(monthlyData).sort();
    const visitCounts = months.map(m => monthlyData[m]);

    const ctx1 = document.getElementById('chartVisits');
    if (ctx1) {
      new Chart(ctx1, {
        type: 'bar',
        data: {
          labels: months.map(m => { const [y,mo] = m.split('-'); return new Date(y,mo-1).toLocaleDateString('id-ID',{month:'short',year:'2-digit'}); }),
          datasets: [{ label: 'Kunjungan', data: visitCounts, backgroundColor: 'rgba(37,99,235,0.8)', borderRadius: 6 }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: '#f1f5f9' } }, x: { grid: { display: false } } } }
      });
    }

    // Payment methods pie
    const methodCount = {};
    payments.forEach(p => { methodCount[p.method] = (methodCount[p.method] || 0) + 1; });
    const ctx2 = document.getElementById('chartPayment');
    if (ctx2) {
      new Chart(ctx2, {
        type: 'doughnut',
        data: {
          labels: Object.keys(methodCount),
          datasets: [{ data: Object.values(methodCount), backgroundColor: ['#3b82f6','#10b981','#f59e0b','#8b5cf6','#ef4444'] }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
      });
    }
  }
};

// Init on DOM ready
document.addEventListener('DOMContentLoaded', () => App.init());
