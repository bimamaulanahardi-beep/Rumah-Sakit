/**
 * SIMRS — Patients Module (Manajemen Pasien)
 */
Modules.Patients = {
  searchQuery: '',
  page: 1,
  perPage: 10,

  render(container) {
    const patients = DB.search('patients', this.searchQuery, ['name','nik','phone']);
    const total = patients.length;
    const start = (this.page - 1) * this.perPage;
    const paged = patients.slice(start, start + this.perPage);
    const totalPages = Math.ceil(total / this.perPage);

    container.innerHTML = `
      <div class="page-header fade-up">
        <div>
          <h2>Data Pasien</h2>
          <p>${total} pasien terdaftar</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-secondary btn-sm">${App.icon('download',14)} Export</button>
          <button class="btn btn-primary btn-sm" onclick="Modules.Patients.showForm(null)">
            ${App.icon('user-plus',14)} Daftarkan Pasien
          </button>
        </div>
      </div>

      <div class="card fade-up">
        <div class="card-header">
          <div class="toolbar" style="margin:0;flex:1;gap:8px">
            <div class="search-bar" style="max-width:280px;flex:1">
              ${App.icon('search',15,'search-icon')}
              <input type="text" id="patSearch" placeholder="Cari nama, NIK, nomor HP..." value="${this.searchQuery}"
                oninput="Modules.Patients.searchQuery=this.value;Modules.Patients.page=1;Modules.Patients.render(document.getElementById('content-area'))" />
            </div>
          </div>
          <span style="font-size:12px;color:var(--text-muted)">${total} data</span>
        </div>

        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead>
              <tr>
                <th>No. MR</th><th>Pasien</th><th>NIK</th><th>Usia / L/P</th><th>Telepon</th><th>Asuransi</th><th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              ${paged.length === 0 ? `<tr><td colspan="7">
                <div class="empty-state">${App.icon('users',40,'','color:var(--text-placeholder)')}<h4>Tidak ada pasien ditemukan</h4><p>Coba ubah kata kunci pencarian</p></div>
              </td></tr>` :
              paged.map(p => `
                <tr style="cursor:pointer" onclick="Modules.Patients.showDetail('${p.id}')">
                  <td><code style="font-size:12px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${p.id}</code></td>
                  <td>
                    <div class="flex items-center gap-2">
                      <div class="avatar avatar-sm avatar-${App.avatarColor(p.name)}">${App.fmt.initials(p.name)}</div>
                      <div>
                        <div class="font-semibold" style="font-size:13px">${p.name}</div>
                        <div style="font-size:11px;color:var(--text-muted)">${p.address ? p.address.substring(0,35)+'...' : '-'}</div>
                      </div>
                    </div>
                  </td>
                  <td style="font-size:12px;font-family:monospace">${p.nik||'-'}</td>
                  <td style="font-size:12px">${App.fmt.age(p.birthDate)} · ${p.gender === 'L' ? '♂' : '♀'}</td>
                  <td style="font-size:12px">${p.phone||'-'}</td>
                  <td>
                    ${p.insurance ? `<span class="badge ${p.insurance==='BPJS'?'badge-success':'badge-primary'}">${p.insurance}</span>` : '<span class="badge badge-neutral">Mandiri</span>'}
                  </td>
                  <td onclick="event.stopPropagation()">
                    <div class="flex gap-1">
                      <button class="btn btn-icon-sm btn-ghost" onclick="Modules.Patients.showDetail('${p.id}')" title="Lihat Detail">${App.icon('eye',14)}</button>
                      <button class="btn btn-icon-sm btn-ghost" onclick="Modules.Patients.showForm('${p.id}')" title="Edit">${App.icon('edit',14)}</button>
                      <button class="btn btn-icon-sm btn-ghost" style="color:var(--danger)" onclick="Modules.Patients.confirmDelete('${p.id}')" title="Hapus">${App.icon('trash',14)}</button>
                    </div>
                  </td>
                </tr>`
              ).join('')}
            </tbody>
          </table>
        </div>

        <div class="pagination">
          <div class="pagination-info">Menampilkan ${start+1}–${Math.min(start+this.perPage,total)} dari ${total} data</div>
          <div class="pagination-btns">
            <button class="page-btn" ${this.page<=1?'disabled':''} onclick="Modules.Patients.page--;Modules.Patients.render(document.getElementById('content-area'))">${App.icon('arrow-left',12)}</button>
            ${Array.from({length:totalPages},(_, i)=>`<button class="page-btn ${this.page===i+1?'active':''}" onclick="Modules.Patients.page=${i+1};Modules.Patients.render(document.getElementById('content-area'))">${i+1}</button>`).slice(Math.max(0,this.page-3),this.page+2).join('')}
            <button class="page-btn" ${this.page>=totalPages?'disabled':''} onclick="Modules.Patients.page++;Modules.Patients.render(document.getElementById('content-area'))">${App.icon('arrow-right',12)}</button>
          </div>
        </div>
      </div>
    `;
  },

  showDetail(id) {
    const p = DB.getOne('patients', id);
    if (!p) return;
    const visits = DB.patientVisits(id);
    const avatarColor = App.avatarColor(p.name);

    App.modal({
      title: 'Detail Pasien',
      subtitle: `No. MR: ${p.id}`,
      size: 'modal-lg',
      body: `
        <div class="flex gap-4 mb-4 items-start">
          <div class="avatar avatar-xl avatar-${avatarColor}">${App.fmt.initials(p.name)}</div>
          <div class="flex-1">
            <div style="font-size:20px;font-weight:800;margin-bottom:4px">${p.name}</div>
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:8px">${p.id} · Terdaftar ${App.fmt.date(p.createdAt)}</div>
            <div class="flex gap-2 flex-wrap">
              ${p.insurance ? `<span class="badge ${p.insurance==='BPJS'?'badge-success':'badge-primary'}">${p.insurance} ${p.insuranceNo?'#'+p.insuranceNo:''}</span>` : ''}
              <span class="badge badge-neutral">${App.fmt.genderLabel(p.gender)}</span>
              <span class="badge badge-neutral">${App.fmt.age(p.birthDate)}</span>
              ${p.bloodType ? `<span class="badge badge-danger">Gol. Darah ${p.bloodType}</span>` : ''}
            </div>
          </div>
          <div class="flex gap-2">
            <button class="btn btn-secondary btn-sm" onclick="App.closeModal();Modules.Patients.showForm('${p.id}')">${App.icon('edit',13)} Edit</button>
          </div>
        </div>

        <div class="tabs">
          <div class="tab-item active" id="tab-info" onclick="Modules.Patients._switchTab('info')">Data Diri</div>
          <div class="tab-item" id="tab-visits" onclick="Modules.Patients._switchTab('visits')">
            Riwayat Kunjungan <span class="tab-count">${visits.length}</span>
          </div>
        </div>

        <div id="tab-content-info">
          <div class="grid-2" style="gap:0">
            <div>
              <div class="info-row"><div class="info-label">NIK</div><div class="info-value" style="font-family:monospace">${p.nik||'-'}</div></div>
              <div class="info-row"><div class="info-label">Tanggal Lahir</div><div class="info-value">${App.fmt.date(p.birthDate)} (${App.fmt.age(p.birthDate)})</div></div>
              <div class="info-row"><div class="info-label">Jenis Kelamin</div><div class="info-value">${App.fmt.genderLabel(p.gender)}</div></div>
              <div class="info-row"><div class="info-label">Gol. Darah</div><div class="info-value">${p.bloodType||'-'}</div></div>
              <div class="info-row"><div class="info-label">Status</div><div class="info-value">${p.maritalStatus||'-'}</div></div>
              <div class="info-row"><div class="info-label">Pekerjaan</div><div class="info-value">${p.job||'-'}</div></div>
            </div>
            <div>
              <div class="info-row"><div class="info-label">No. HP</div><div class="info-value">${p.phone||'-'}</div></div>
              <div class="info-row"><div class="info-label">Email</div><div class="info-value">${p.email||'-'}</div></div>
              <div class="info-row"><div class="info-label">Alamat</div><div class="info-value">${p.address||'-'}</div></div>
              <div class="info-row"><div class="info-label">Asuransi</div><div class="info-value">${p.insurance||'Mandiri'}</div></div>
              <div class="info-row"><div class="info-label">No. Asuransi</div><div class="info-value" style="font-family:monospace">${p.insuranceNo||'-'}</div></div>
            </div>
          </div>
        </div>

        <div id="tab-content-visits" style="display:none">
          ${visits.length === 0 ? `<div class="empty-state">${App.icon('calendar',32,'','color:var(--text-placeholder)')}<h4>Belum ada kunjungan</h4></div>` :
          visits.map(v => {
            const doc = DB.getOne('doctors', v.doctorId);
            const emr = DB.visitEMR(v.id);
            return `
              <div class="rx-item" style="cursor:pointer" onclick="App.closeModal();App.navigate('emr')">
                <div>
                  <div class="font-semibold">${App.fmt.dateShort(v.date)} — ${doc?.name?.split(',')[0]||'-'}</div>
                  <div class="text-sm text-muted-color mt-1">${v.chiefComplaint||'-'}</div>
                  ${emr ? `<div class="text-sm mt-1" style="color:var(--info)">Dx: ${emr.diagnosis?.substring(0,60)||'-'}</div>` : ''}
                </div>
                ${App.statusBadge(v.status)}
              </div>`;
          }).join('')}
        </div>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Tutup</button>
        <button class="btn btn-primary" onclick="App.closeModal();App.navigate('scheduling')">
          ${App.icon('calendar-clock',14)} Buat Kunjungan Baru
        </button>
      `
    });
  },

  _switchTab(tab) {
    document.querySelectorAll('.tab-item').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-info').classList.toggle('active', tab === 'info');
    document.getElementById('tab-visits').classList.toggle('active', tab === 'visits');
    document.getElementById('tab-content-info').style.display = tab === 'info' ? '' : 'none';
    document.getElementById('tab-content-visits').style.display = tab === 'visits' ? '' : 'none';
  },

  showForm(id) {
    const p = id ? DB.getOne('patients', id) : null;
    const title = p ? 'Edit Data Pasien' : 'Daftarkan Pasien Baru';

    App.modal({
      title,
      size: 'modal-lg',
      body: `
        <form id="patientForm" onsubmit="Modules.Patients.save(event,'${id||''}')">
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">Nama Lengkap <span class="required">*</span></label>
              <input class="form-control" name="name" required value="${p?.name||''}" placeholder="Nama lengkap pasien" />
            </div>
            <div class="form-group">
              <label class="form-label">NIK <span class="required">*</span></label>
              <input class="form-control" name="nik" required value="${p?.nik||''}" placeholder="16 digit NIK" maxlength="16" />
            </div>
            <div class="form-group">
              <label class="form-label">Tanggal Lahir <span class="required">*</span></label>
              <input class="form-control" type="date" name="birthDate" required value="${p?.birthDate||''}" />
            </div>
            <div class="form-group">
              <label class="form-label">Jenis Kelamin <span class="required">*</span></label>
              <select class="form-control" name="gender" required>
                <option value="">Pilih...</option>
                <option value="L" ${p?.gender==='L'?'selected':''}>Laki-laki</option>
                <option value="P" ${p?.gender==='P'?'selected':''}>Perempuan</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">No. Telepon</label>
              <input class="form-control" name="phone" value="${p?.phone||''}" placeholder="08xxxxxxxxxx" />
            </div>
            <div class="form-group">
              <label class="form-label">Email</label>
              <input class="form-control" type="email" name="email" value="${p?.email||''}" placeholder="email@contoh.com" />
            </div>
            <div class="form-group">
              <label class="form-label">Golongan Darah</label>
              <select class="form-control" name="bloodType">
                <option value="">Tidak diketahui</option>
                ${['A','B','AB','O'].map(b=>`<option value="${b}" ${p?.bloodType===b?'selected':''}>${b}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Status Pernikahan</label>
              <select class="form-control" name="maritalStatus">
                ${['Belum Menikah','Menikah','Cerai'].map(s=>`<option value="${s}" ${p?.maritalStatus===s?'selected':''}>${s}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Pekerjaan</label>
              <input class="form-control" name="job" value="${p?.job||''}" placeholder="Pekerjaan pasien" />
            </div>
            <div class="form-group">
              <label class="form-label">Asuransi</label>
              <select class="form-control" name="insurance">
                <option value="">Mandiri (Bayar Sendiri)</option>
                ${['BPJS','Asuransi Jiwa','Jasa Raharja','Pensiunan'].map(i=>`<option value="${i}" ${p?.insurance===i?'selected':''}>${i}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">No. Asuransi</label>
              <input class="form-control" name="insuranceNo" value="${p?.insuranceNo||''}" placeholder="Nomor kartu asuransi" />
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Alamat Lengkap</label>
            <textarea class="form-control" name="address" rows="2" placeholder="Alamat lengkap pasien">${p?.address||''}</textarea>
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-primary" onclick="document.getElementById('patientForm').requestSubmit()">
          ${App.icon('save',14)} ${p ? 'Simpan Perubahan' : 'Daftarkan Pasien'}
        </button>
      `
    });
  },

  save(e, id) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));

    if (id) {
      DB.update('patients', id, data);
      App.toast('Data pasien berhasil diperbarui', 'success');
    } else {
      const newId = 'PAT' + String(DB.count('patients') + 1).padStart(3, '0');
      DB.insert('patients', { id: newId, ...data });
      App.toast(`Pasien ${data.name} berhasil didaftarkan (${newId})`, 'success');
    }
    App.closeModal();
    this.render(document.getElementById('content-area'));
  },

  confirmDelete(id) {
    const p = DB.getOne('patients', id);
    App.confirm({
      title: 'Hapus Data Pasien',
      message: `Yakin ingin menghapus data pasien <strong>${p?.name}</strong>? Data yang dihapus tidak dapat dikembalikan.`,
      confirmLabel: 'Hapus',
      confirmClass: 'btn-danger',
      onConfirm: () => {
        DB.delete('patients', id);
        App.toast('Data pasien berhasil dihapus', 'info');
        Modules.Patients.render(document.getElementById('content-area'));
      }
    });
  }
};
