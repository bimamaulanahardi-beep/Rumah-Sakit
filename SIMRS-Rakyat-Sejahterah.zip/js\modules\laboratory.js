/**
 * SIMRS — Laboratory Module
 */
Modules.Laboratory = {
  activeTab: 'orders',

  LAB_TESTS: [
    { code: 'DL',   name: 'Darah Lengkap (CBC)',        price: 75000 },
    { code: 'GDP',  name: 'Gula Darah Puasa',           price: 35000 },
    { code: 'GDS',  name: 'Gula Darah Sewaktu',         price: 30000 },
    { code: 'HbA1c',name: 'HbA1c',                     price: 85000 },
    { code: 'UR',   name: 'Ureum & Kreatinin',          price: 65000 },
    { code: 'SGOT', name: 'SGOT/SGPT (Fungsi Hati)',    price: 60000 },
    { code: 'UA',   name: 'Asam Urat',                  price: 35000 },
    { code: 'CHOL', name: 'Kolesterol Total',           price: 40000 },
    { code: 'LDL',  name: 'Profil Lipid (LDL/HDL/TG)', price: 95000 },
    { code: 'WID',  name: 'Widal Test',                 price: 50000 },
    { code: 'NS1',  name: 'Antigen NS1 Dengue',         price: 120000 },
    { code: 'IGMD', name: 'IgM/IgG Dengue',            price: 100000 },
    { code: 'HBSAG',name: 'HBsAg',                     price: 70000 },
    { code: 'COVID',name: 'Rapid Antigen COVID-19',     price: 50000 },
    { code: 'URIN', name: 'Urinalisis Lengkap',         price: 45000 },
    { code: 'FESES',name: 'Analisis Feses',             price: 40000 },
    { code: 'BTK',  name: 'Waktu Perdarahan & Pembekuan', price: 30000 },
    { code: 'ELISA',name: 'ELISA HIV',                  price: 150000 },
  ],

  render(container) {
    const orders = DB.get('labOrders');
    const pending = orders.filter(o => o.status !== 'selesai').length;

    container.innerHTML = `
      <div class="page-header fade-up">
        <div>
          <h2>Laboratorium</h2>
          <p>${orders.length} permintaan lab · ${pending} pending</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary" onclick="Modules.Laboratory.showNewOrderForm()">
            ${App.icon('file-plus',14)} Permintaan Lab
          </button>
        </div>
      </div>

      <div class="tabs fade-up">
        <div class="tab-item ${this.activeTab==='orders'?'active':''}" onclick="Modules.Laboratory._switchTab('orders')">
          ${App.icon('clipboard',14)} Semua Order
          <span class="tab-count">${orders.length}</span>
        </div>
        <div class="tab-item ${this.activeTab==='pending'?'active':''}" onclick="Modules.Laboratory._switchTab('pending')">
          ${App.icon('clock',14)} Pending
          <span class="tab-count">${pending}</span>
        </div>
        <div class="tab-item ${this.activeTab==='tests'?'active':''}" onclick="Modules.Laboratory._switchTab('tests')">
          ${App.icon('test-tube',14)} Daftar Pemeriksaan
        </div>
      </div>

      <div id="lab-content" class="fade-up"></div>
    `;

    this._renderActiveTab();
  },

  _switchTab(tab) {
    this.activeTab = tab;
    document.querySelectorAll('.tab-item').forEach((t,i) => t.classList.toggle('active', (i===0&&tab==='orders')||(i===1&&tab==='pending')||(i===2&&tab==='tests')));
    this._renderActiveTab();
  },

  _renderActiveTab() {
    const el = document.getElementById('lab-content');
    if (!el) return;
    if (this.activeTab === 'tests') {
      el.innerHTML = this._testsHTML();
    } else {
      const filter = this.activeTab === 'pending' ? o => o.status !== 'selesai' : () => true;
      el.innerHTML = this._ordersHTML(DB.get('labOrders').filter(filter));
    }
  },

  _ordersHTML(orders) {
    const sorted = orders.sort((a,b) => new Date(b.requestedAt) - new Date(a.requestedAt));
    return `
      <div class="card">
        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead>
              <tr><th>ID</th><th>Pasien</th><th>Pemeriksaan</th><th>Diminta</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
              ${sorted.length === 0 ? `<tr><td colspan="6"><div class="empty-state">${App.icon('microscope',40,'','color:var(--text-placeholder)')}<h4>Tidak ada order lab</h4></div></td></tr>` :
              sorted.map(o => {
                const visit = DB.getOne('visits', o.visitId);
                const pat = visit ? DB.getOne('patients', visit.patientId) : null;
                const statusColors = { 'pending':'badge-warning', 'proses':'badge-info', 'selesai':'badge-success' };
                const statusLabels = { 'pending':'Pending', 'proses':'Diproses', 'selesai':'Selesai' };
                return `
                  <tr>
                    <td><code style="font-size:11px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${o.id}</code></td>
                    <td>
                      <div class="flex items-center gap-2">
                        <div class="avatar avatar-sm avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
                        <div class="font-semibold" style="font-size:13px">${pat?.name||'—'}</div>
                      </div>
                    </td>
                    <td>
                      <div style="font-size:12px">
                        ${(o.tests||[]).map(t=>`<span class="badge badge-neutral" style="margin:1px;font-size:10.5px">${t.name}</span>`).join('')}
                      </div>
                    </td>
                    <td style="font-size:12px;white-space:nowrap">${App.fmt.datetime(o.requestedAt)}</td>
                    <td><span class="badge badge-status ${statusColors[o.status]||'badge-neutral'}">${statusLabels[o.status]||o.status}</span></td>
                    <td>
                      <div class="flex gap-1">
                        <button class="btn btn-xs btn-outline-primary" onclick="Modules.Laboratory.showOrderDetail('${o.id}')">${App.icon('eye',12)} Detail</button>
                        ${o.status !== 'selesai' ? `
                          <button class="btn btn-xs btn-success" onclick="Modules.Laboratory.showResultForm('${o.id}')">
                            ${App.icon('flask',12)} Input Hasil
                          </button>` : ''}
                      </div>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  _testsHTML() {
    return `
      <div class="card">
        <div class="card-header"><span class="card-title">${App.icon('test-tube',16)} Daftar Pemeriksaan Laboratorium</span></div>
        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead><tr><th>#</th><th>Kode</th><th>Nama Pemeriksaan</th><th>Harga</th></tr></thead>
            <tbody>
              ${this.LAB_TESTS.map((t,i) => `
                <tr>
                  <td style="font-size:12px;color:var(--text-muted)">${i+1}</td>
                  <td><code style="font-size:11px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${t.code}</code></td>
                  <td style="font-size:13px;font-weight:500">${t.name}</td>
                  <td style="font-size:13px;font-weight:600">${App.fmt.currency(t.price)}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  showNewOrderForm() {
    const patients = DB.get('patients');
    const today = new Date().toISOString().split('T')[0];
    const todayVisits = DB.get('visits').filter(v => v.date === today && v.status !== 'batal');

    App.modal({
      title: 'Permintaan Pemeriksaan Lab',
      size: 'modal-lg',
      body: `
        <form id="labForm" onsubmit="Modules.Laboratory.saveOrder(event)">
          <div class="form-group">
            <label class="form-label">Kunjungan / Pasien <span class="required">*</span></label>
            <select class="form-control" name="visitId" required>
              <option value="">Pilih kunjungan hari ini...</option>
              ${todayVisits.map(v => {
                const pat = DB.getOne('patients', v.patientId);
                return `<option value="${v.id}">${pat?.name||'—'} — No. ${String(v.queueNo).padStart(3,'0')}</option>`;
              }).join('')}
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Pilih Pemeriksaan <span class="required">*</span></label>
            <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;max-height:300px;overflow-y:auto;padding:4px">
              ${this.LAB_TESTS.map(t => `
                <label class="form-check" style="border:1px solid var(--border);border-radius:var(--radius-xs);padding:8px 10px;cursor:pointer;transition:all 0.15s"
                  onchange="this.style.background=this.querySelector('input').checked?'var(--primary-subtle)':'';this.style.borderColor=this.querySelector('input').checked?'var(--primary)':''">
                  <input type="checkbox" name="tests" value="${t.code}" data-name="${t.name}" />
                  <div>
                    <div class="font-semibold" style="font-size:12px">${t.name}</div>
                    <div style="font-size:11px;color:var(--text-muted)">${App.fmt.currency(t.price)}</div>
                  </div>
                </label>`).join('')}
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Catatan</label>
            <textarea class="form-control" name="notes" rows="2" placeholder="Catatan klinis untuk analis..."></textarea>
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-primary" onclick="document.getElementById('labForm').requestSubmit()">
          ${App.icon('send',14)} Kirim ke Lab
        </button>
      `
    });
  },

  saveOrder(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    const checkedBoxes = e.target.querySelectorAll('input[name="tests"]:checked');

    if (!checkedBoxes.length) { App.toast('Pilih minimal satu pemeriksaan', 'warning'); return; }

    const tests = Array.from(checkedBoxes).map(cb => ({
      code: cb.value,
      name: cb.dataset.name,
    }));

    const orderId = 'LAB' + Date.now().toString().slice(-6);
    DB.insert('labOrders', {
      id: orderId,
      visitId: data.visitId,
      tests,
      status: 'pending',
      requestedBy: App.user.id,
      requestedAt: new Date().toISOString(),
      results: [],
      resultAt: null,
      resultBy: null,
      notes: data.notes || '',
    });

    App.toast(`Order lab ${orderId} berhasil dikirim ke laboratorium`, 'success');
    App.closeModal();
    this.render(document.getElementById('content-area'));
  },

  showResultForm(orderId) {
    const order = DB.getOne('labOrders', orderId);
    if (!order) return;

    App.modal({
      title: 'Input Hasil Pemeriksaan',
      subtitle: `Order #${orderId}`,
      size: 'modal-lg',
      body: `
        <form id="resultForm" onsubmit="Modules.Laboratory.saveResults(event,'${orderId}')">
          ${(order.tests || []).map((test, ti) => `
            <div style="background:#f8fafc;border:1px solid var(--border);border-radius:var(--radius-sm);padding:14px;margin-bottom:12px">
              <div class="font-bold mb-3" style="font-size:13px;color:var(--text-secondary)">${test.name}</div>
              <div id="result-container-${ti}">
                ${this._getTestResultFields(test.code, ti, order.results||[])}
              </div>
            </div>`).join('')}

          <div class="form-group">
            <label class="form-label">Catatan Analis</label>
            <textarea class="form-control" name="notes" rows="2" placeholder="Interpretasi atau catatan tambahan...">${order.notes||''}</textarea>
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-success" onclick="document.getElementById('resultForm').requestSubmit()">
          ${App.icon('check',14)} Simpan Hasil
        </button>
      `
    });
  },

  _getTestResultFields(code, testIdx, existingResults) {
    const templates = {
      'DL': [
        {name:'Hemoglobin', unit:'g/dL', normal:'12-16 g/dL'},
        {name:'Leukosit', unit:'/µL', normal:'4000-10000 /µL'},
        {name:'Trombosit', unit:'/µL', normal:'150000-400000 /µL'},
        {name:'Hematokrit', unit:'%', normal:'37-47 %'},
        {name:'Eritrosit', unit:'juta/µL', normal:'4.5-5.5 juta/µL'},
      ],
      'GDP': [{name:'Gula Darah Puasa', unit:'mg/dL', normal:'70-100 mg/dL'}],
      'GDS': [{name:'Gula Darah Sewaktu', unit:'mg/dL', normal:'< 200 mg/dL'}],
      'HbA1c': [{name:'HbA1c', unit:'%', normal:'< 5.7 %'}],
      'WID': [
        {name:'Widal O', unit:'', normal:'< 1/80'},
        {name:'Widal H', unit:'', normal:'< 1/80'},
        {name:'Widal OA', unit:'', normal:'< 1/80'},
        {name:'Widal HA', unit:'', normal:'< 1/80'},
      ],
      'NS1': [{name:'NS1 Antigen', unit:'', normal:'Non-Reaktif'}],
      'IGMD': [{name:'IgM Dengue', unit:'', normal:'Non-Reaktif'},{name:'IgG Dengue', unit:'', normal:'Non-Reaktif'}],
      'UA': [{name:'Asam Urat', unit:'mg/dL', normal:'3.5-7.2 mg/dL'}],
      'CHOL': [{name:'Kolesterol Total', unit:'mg/dL', normal:'< 200 mg/dL'}],
      'LDL': [
        {name:'Kolesterol Total', unit:'mg/dL', normal:'< 200 mg/dL'},
        {name:'LDL', unit:'mg/dL', normal:'< 100 mg/dL'},
        {name:'HDL', unit:'mg/dL', normal:'> 50 mg/dL'},
        {name:'Trigliserida', unit:'mg/dL', normal:'< 150 mg/dL'},
      ],
      'UR': [
        {name:'Ureum', unit:'mg/dL', normal:'10-50 mg/dL'},
        {name:'Kreatinin', unit:'mg/dL', normal:'0.6-1.2 mg/dL'},
      ],
      'SGOT': [
        {name:'SGOT (AST)', unit:'U/L', normal:'< 37 U/L'},
        {name:'SGPT (ALT)', unit:'U/L', normal:'< 41 U/L'},
      ],
    };

    const fields = templates[code] || [{name: code, unit:'', normal:''}];

    return fields.map((f,i) => {
      const existing = existingResults.find(r => r.test === f.name);
      return `
        <div class="form-grid" style="gap:10px;margin-bottom:8px">
          <div class="form-group" style="margin:0">
            <label class="form-label" style="font-size:11px">${f.name}</label>
            <input class="form-control" name="result_${testIdx}_${i}_test" value="${f.name}" readonly style="background:#f1f5f9;font-size:12px" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label" style="font-size:11px">Hasil</label>
            <input class="form-control" name="result_${testIdx}_${i}_value" value="${existing?.value||''}" placeholder="Nilai hasil" style="font-size:12px" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label" style="font-size:11px">Satuan</label>
            <input class="form-control" name="result_${testIdx}_${i}_unit" value="${f.unit}" placeholder="${f.unit}" style="font-size:12px" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label" style="font-size:11px">Nilai Normal</label>
            <input class="form-control" name="result_${testIdx}_${i}_normal" value="${f.normal}" style="font-size:12px;background:#f1f5f9" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label" style="font-size:11px">Flag</label>
            <select class="form-control" name="result_${testIdx}_${i}_flag" style="font-size:12px">
              <option value="N" ${existing?.flag==='N'?'selected':''}>Normal</option>
              <option value="H" ${existing?.flag==='H'?'selected':''}>Tinggi (H)</option>
              <option value="L" ${existing?.flag==='L'?'selected':''}>Rendah (L)</option>
            </select>
          </div>
        </div>`;
    }).join('');
  },

  saveResults(e, orderId) {
    e.preventDefault();
    const form = e.target;
    const results = [];

    // Parse all result fields
    const order = DB.getOne('labOrders', orderId);
    if (!order) return;

    // Collect form data by pattern
    const allFields = {};
    new FormData(form).forEach((v, k) => { allFields[k] = v; });

    // Group by result_ti_fi_type
    const resultMap = {};
    Object.entries(allFields).forEach(([k, v]) => {
      const match = k.match(/^result_(\d+)_(\d+)_(.+)$/);
      if (match) {
        const key = `${match[1]}_${match[2]}`;
        resultMap[key] = resultMap[key] || {};
        resultMap[key][match[3]] = v;
      }
    });

    Object.values(resultMap).forEach(r => {
      if (r.value) {
        results.push({
          test: r.test,
          value: r.value,
          unit: r.unit || '',
          normalRange: r.normal || '',
          flag: r.flag || 'N',
        });
      }
    });

    if (!results.length) { App.toast('Masukkan minimal satu hasil pemeriksaan', 'warning'); return; }

    DB.update('labOrders', orderId, {
      status: 'selesai',
      results,
      resultAt: new Date().toISOString(),
      resultBy: App.user.id,
      notes: allFields.notes || '',
    });

    App.toast('Hasil lab berhasil disimpan', 'success');
    App.closeModal();
    this.render(document.getElementById('content-area'));
  },

  showOrderDetail(orderId) {
    const order = DB.getOne('labOrders', orderId);
    if (!order) return;
    const visit = DB.getOne('visits', order.visitId);
    const pat = visit ? DB.getOne('patients', visit.patientId) : null;
    const requestedBy = DB.getOne('users', order.requestedBy);
    const resultBy = DB.getOne('users', order.resultBy);

    const statusColors = { 'pending':'badge-warning', 'proses':'badge-info', 'selesai':'badge-success' };

    App.modal({
      title: `Hasil Lab — ${order.id}`,
      subtitle: `${pat?.name||''} — ${App.fmt.datetime(order.requestedAt)}`,
      size: 'modal-lg',
      body: `
        <div class="flex gap-3 items-center p-3 mb-4" style="background:#f8fafc;border-radius:var(--radius-sm);border:1px solid var(--border)">
          <div class="avatar avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
          <div class="flex-1">
            <div class="font-bold">${pat?.name||'—'}</div>
            <div style="font-size:12px;color:var(--text-muted)">Diminta oleh: ${requestedBy?.name||order.requestedBy} · ${App.fmt.datetime(order.requestedAt)}</div>
          </div>
          <span class="badge badge-status ${statusColors[order.status]||'badge-neutral'}">${order.status}</span>
        </div>

        <div class="mb-4">
          <div class="font-semibold mb-2" style="font-size:12px;color:var(--text-muted);text-transform:uppercase">Pemeriksaan yang Diminta</div>
          <div class="flex flex-wrap gap-2">
            ${(order.tests||[]).map(t=>`<span class="badge badge-primary">${t.name}</span>`).join('')}
          </div>
        </div>

        ${order.results?.length ? `
          <div>
            <div class="font-semibold mb-2" style="font-size:12px;color:var(--text-muted);text-transform:uppercase">Hasil Pemeriksaan</div>
            <div class="table-container">
              <table class="table">
                <thead>
                  <tr><th>Pemeriksaan</th><th>Hasil</th><th>Satuan</th><th>Nilai Normal</th><th>Flag</th></tr>
                </thead>
                <tbody>
                  ${order.results.map(r => `
                    <tr>
                      <td style="font-weight:600;font-size:13px">${r.test}</td>
                      <td style="font-weight:700;font-size:14px;color:${r.flag==='H'?'var(--danger)':r.flag==='L'?'var(--info)':'var(--success)'}">${r.value}</td>
                      <td style="font-size:12px;color:var(--text-muted)">${r.unit}</td>
                      <td style="font-size:12px;color:var(--text-muted)">${r.normalRange}</td>
                      <td>
                        <span class="badge ${r.flag==='H'?'badge-danger':r.flag==='L'?'badge-info':'badge-success'}">
                          ${r.flag==='H'?'TINGGI':r.flag==='L'?'RENDAH':'NORMAL'}
                        </span>
                      </td>
                    </tr>`).join('')}
                </tbody>
              </table>
            </div>
            ${order.notes ? `<div class="alert alert-info mt-3">${App.icon('info',14)} <strong>Catatan Analis:</strong> ${order.notes}</div>` : ''}
            <div style="font-size:11px;color:var(--text-muted);margin-top:8px">
              Diverifikasi oleh: ${resultBy?.name||order.resultBy||'—'} pada ${App.fmt.datetime(order.resultAt)}
            </div>
          </div>` : `
          <div class="empty-state" style="padding:24px">
            ${App.icon('clock',32,'','color:var(--text-placeholder)')}
            <h4>Hasil Belum Tersedia</h4>
            <p>Pemeriksaan sedang diproses oleh analis</p>
          </div>`}
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Tutup</button>
        ${order.status !== 'selesai' ? `
          <button class="btn btn-success" onclick="App.closeModal();Modules.Laboratory.showResultForm('${orderId}')">
            ${App.icon('flask',14)} Input Hasil
          </button>` : ''}
      `
    });
  }
};
