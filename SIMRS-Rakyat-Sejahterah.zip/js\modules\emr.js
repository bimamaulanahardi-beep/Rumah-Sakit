/**
 * SIMRS — EMR Module (Rekam Medis Elektronik)
 */
Modules.EMR = {
  searchQuery: '',

  render(container) {
    const emrList = DB.get('emr').sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
    const visits  = DB.get('visits');
    const patients = DB.get('patients');
    const doctors  = DB.get('doctors');

    // Filter by search
    const filtered = emrList.filter(e => {
      if (!this.searchQuery) return true;
      const visit = DB.getOne('visits', e.visitId);
      const pat = visit ? DB.getOne('patients', visit.patientId) : null;
      const q = this.searchQuery.toLowerCase();
      return (pat?.name||'').toLowerCase().includes(q) ||
             (e.diagnosis||'').toLowerCase().includes(q) ||
             (e.assessment||'').toLowerCase().includes(q);
    });

    container.innerHTML = `
      <div class="page-header fade-up">
        <div>
          <h2>Rekam Medis Elektronik</h2>
          <p>${emrList.length} rekam medis tersimpan</p>
        </div>
        ${App.user.role === 'dokter' || App.user.role === 'admin' ? `
        <button class="btn btn-primary" onclick="Modules.EMR.showNewEMRPicker()">
          ${App.icon('file-plus',14)} Buat Rekam Medis
        </button>` : ''}
      </div>

      <div class="card fade-up">
        <div class="card-header">
          <div class="search-bar" style="max-width:280px;flex:1">
            ${App.icon('search',15,'search-icon')}
            <input type="text" placeholder="Cari nama pasien, diagnosis..." value="${this.searchQuery}"
              oninput="Modules.EMR.searchQuery=this.value;Modules.EMR.render(document.getElementById('content-area'))" />
          </div>
          <span style="font-size:12px;color:var(--text-muted)">${filtered.length} rekam medis</span>
        </div>

        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead>
              <tr><th>Tanggal</th><th>Pasien</th><th>Dokter</th><th>Keluhan</th><th>Diagnosis</th><th>Aksi</th></tr>
            </thead>
            <tbody>
              ${filtered.length === 0 ? `<tr><td colspan="6"><div class="empty-state">${App.icon('file-text',40,'','color:var(--text-placeholder)')}<h4>Belum ada rekam medis</h4></div></td></tr>` :
              filtered.map(e => {
                const visit = DB.getOne('visits', e.visitId);
                const pat = visit ? DB.getOne('patients', visit.patientId) : null;
                const doc = visit ? DB.getOne('doctors', visit.doctorId) : null;
                const rxCount = DB.emrPrescriptions(e.id).length;
                return `
                  <tr style="cursor:pointer" onclick="Modules.EMR.showDetail('${e.id}')">
                    <td style="font-size:12px;white-space:nowrap">${App.fmt.dateShort(visit?.date)}</td>
                    <td>
                      <div class="flex items-center gap-2">
                        <div class="avatar avatar-sm avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
                        <div>
                          <div class="font-semibold" style="font-size:13px">${pat?.name||'—'}</div>
                          <div style="font-size:11px;color:var(--text-muted)">${pat?.id||''}</div>
                        </div>
                      </div>
                    </td>
                    <td style="font-size:12px;color:var(--text-secondary)">${doc?.name?.split(',')[0]||'—'}</td>
                    <td style="font-size:12px;max-width:160px" class="truncate">${visit?.chiefComplaint||'—'}</td>
                    <td style="font-size:12px;max-width:200px" class="truncate">${e.diagnosis||'—'}</td>
                    <td onclick="event.stopPropagation()">
                      <div class="flex gap-1">
                        <button class="btn btn-xs btn-outline-primary" onclick="Modules.EMR.showDetail('${e.id}')">${App.icon('eye',12)} Lihat</button>
                        ${App.user.role !== 'kasir' && App.user.role !== 'lab' ? `<button class="btn btn-xs btn-secondary" onclick="Modules.EMR.showForm('${visit?.id}')">${App.icon('edit',12)}</button>` : ''}
                      </div>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  showNewEMRPicker() {
    // Pick from today's visited (dipanggil/selesai without EMR)
    const today = new Date().toISOString().split('T')[0];
    const todayVisits = DB.get('visits').filter(v => v.date === today && (v.status === 'dipanggil' || v.status === 'selesai'));
    const existingEMRvisits = DB.get('emr').map(e => e.visitId);
    const candidates = todayVisits.filter(v => !existingEMRvisits.includes(v.id));

    if (candidates.length === 0) {
      App.toast('Tidak ada pasien yang perlu dibuat rekam medis saat ini. Pastikan pasien sudah dipanggil.', 'warning');
      return;
    }

    App.modal({
      title: 'Pilih Kunjungan',
      subtitle: 'Pilih kunjungan pasien untuk dibuat rekam medisnya',
      body: `
        <div style="display:flex;flex-direction:column;gap:8px">
          ${candidates.map(v => {
            const pat = DB.getOne('patients', v.patientId);
            const doc = DB.getOne('doctors', v.doctorId);
            return `
              <div class="rx-item" style="cursor:pointer" onclick="App.closeModal();setTimeout(()=>Modules.EMR.showForm('${v.id}'),200)">
                <div>
                  <div class="font-semibold">${pat?.name||'—'} <span class="badge badge-neutral ml-auto">#${String(v.queueNo).padStart(3,'0')}</span></div>
                  <div class="text-sm text-muted-color mt-1">${doc?.name||''} · ${v.chiefComplaint||''}</div>
                </div>
                ${App.icon('arrow-right',16,'','color:var(--primary)')}
              </div>`;
          }).join('')}
        </div>
      `
    });
  },

  showForm(visitId) {
    const visit = DB.getOne('visits', visitId);
    if (!visit) { App.toast('Kunjungan tidak ditemukan', 'error'); return; }
    const pat = DB.getOne('patients', visit.patientId);
    const doc = DB.getOne('doctors', visit.doctorId);
    const existing = DB.visitEMR(visitId);

    App.modal({
      title: existing ? 'Edit Rekam Medis' : 'Buat Rekam Medis',
      subtitle: `${pat?.name||''} — ${App.fmt.dateShort(visit.date)}`,
      size: 'modal-xl',
      body: `
        <div class="alert alert-info mb-4">
          ${App.icon('info',15)}
          <div><strong>Pasien:</strong> ${pat?.name||''} (${App.fmt.age(pat?.birthDate)}, ${App.fmt.genderLabel(pat?.gender)}) &nbsp;|&nbsp; <strong>Alergi diketahui:</strong> ${existing?.allergies||'Tidak ada'}</div>
        </div>

        <form id="emrForm" onsubmit="Modules.EMR.saveEMR(event,'${visitId}','${existing?.id||''}')">

          <!-- Vital Signs -->
          <div style="background:#f8fafc;border:1px solid var(--border);border-radius:var(--radius-sm);padding:16px;margin-bottom:20px">
            <div class="font-semibold mb-3" style="font-size:13px;color:var(--text-secondary)">${App.icon('activity',14,'','vertical-align:middle')} Tanda-Tanda Vital</div>
            <div class="form-grid-3" style="gap:12px">
              <div class="form-group" style="margin:0">
                <label class="form-label">Sistol (mmHg)</label>
                <input class="form-control" name="sistol" type="number" value="${existing?.vitalSigns?.sistol||''}" placeholder="120" />
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">Diastol (mmHg)</label>
                <input class="form-control" name="diastol" type="number" value="${existing?.vitalSigns?.diastol||''}" placeholder="80" />
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">Nadi (x/mnt)</label>
                <input class="form-control" name="nadi" type="number" value="${existing?.vitalSigns?.nadi||''}" placeholder="80" />
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">Suhu (°C)</label>
                <input class="form-control" name="suhu" type="number" step="0.1" value="${existing?.vitalSigns?.suhu||''}" placeholder="36.5" />
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">Napas RR (x/mnt)</label>
                <input class="form-control" name="rr" type="number" value="${existing?.vitalSigns?.rr||''}" placeholder="18" />
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">SpO2 (%)</label>
                <input class="form-control" name="spo2" type="number" value="${existing?.vitalSigns?.spo2||''}" placeholder="98" />
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">BB (kg)</label>
                <input class="form-control" name="bb" type="number" step="0.1" value="${existing?.vitalSigns?.bb||''}" placeholder="60" />
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">TB (cm)</label>
                <input class="form-control" name="tb" type="number" value="${existing?.vitalSigns?.tb||''}" placeholder="165" />
              </div>
            </div>
          </div>

          <!-- SOAP -->
          <div class="form-group">
            <label class="form-label">S — Subjective (Anamnesis Pasien) <span class="required">*</span></label>
            <textarea class="form-control" name="subjective" rows="3" required placeholder="Keluhan utama, riwayat penyakit, kronologi...">${existing?.subjective||''}</textarea>
          </div>
          <div class="form-group">
            <label class="form-label">O — Objective (Pemeriksaan Fisik)</label>
            <textarea class="form-control" name="objective" rows="3" placeholder="Keadaan umum, tanda vital, pemeriksaan organ...">${existing?.objective||''}</textarea>
          </div>
          <div class="form-group">
            <label class="form-label">A — Assessment (Penilaian Klinis) <span class="required">*</span></label>
            <textarea class="form-control" name="assessment" rows="2" required placeholder="Diagnosis kerja, diagnosis banding...">${existing?.assessment||''}</textarea>
          </div>
          <div class="form-group">
            <label class="form-label">P — Plan (Rencana Tindakan)</label>
            <textarea class="form-control" name="plan" rows="3" placeholder="Terapi, anjuran, kontrol ulang...">${existing?.plan||''}</textarea>
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">Diagnosis Utama (ICD-10)</label>
              <input class="form-control" name="diagnosis" value="${existing?.diagnosis||''}" placeholder="mis. J06.9 - ISPA" />
            </div>
            <div class="form-group">
              <label class="form-label">Diagnosis Sekunder</label>
              <input class="form-control" name="secondaryDiagnosis" value="${existing?.secondaryDiagnosis||''}" placeholder="Diagnosis penyerta" />
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Alergi</label>
            <input class="form-control" name="allergies" value="${existing?.allergies||''}" placeholder="Obat, makanan, atau alergi lain yang diketahui" />
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        ${existing ? `<button class="btn btn-outline-primary" onclick="App.closeModal();Modules.EMR.showPrescriptionForm('${existing.id}','${visitId}')">
          ${App.icon('pill',14)} Buat Resep
        </button>` : ''}
        <button class="btn btn-primary" onclick="document.getElementById('emrForm').requestSubmit()">
          ${App.icon('save',14)} Simpan Rekam Medis
        </button>
      `
    });
  },

  saveEMR(e, visitId, existingId) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd);

    const emrData = {
      visitId,
      subjective: data.subjective,
      objective: data.objective,
      assessment: data.assessment,
      plan: data.plan,
      diagnosis: data.diagnosis,
      secondaryDiagnosis: data.secondaryDiagnosis,
      allergies: data.allergies,
      vitalSigns: {
        sistol: data.sistol, diastol: data.diastol, nadi: data.nadi,
        suhu: data.suhu, rr: data.rr, spo2: data.spo2, bb: data.bb, tb: data.tb
      },
      createdBy: App.user.id,
    };

    let emrId;
    if (existingId) {
      DB.update('emr', existingId, emrData);
      emrId = existingId;
      App.toast('Rekam medis berhasil diperbarui', 'success');
    } else {
      emrId = 'EMR' + Date.now().toString().slice(-6);
      DB.insert('emr', { id: emrId, ...emrData });
      // Mark visit as selesai
      DB.update('visits', visitId, { status: 'selesai' });
      App.toast('Rekam medis berhasil disimpan', 'success');
    }

    App.closeModal();
    // Prompt to create prescription
    setTimeout(() => {
      App.confirm({
        title: 'Buat Resep?',
        message: 'Rekam medis berhasil disimpan. Apakah ingin membuat resep untuk pasien ini?',
        confirmLabel: 'Ya, Buat Resep',
        confirmClass: 'btn-primary',
        onConfirm: () => { Modules.EMR.showPrescriptionForm(emrId, visitId); }
      });
    }, 300);

    this.render(document.getElementById('content-area'));
  },

  showPrescriptionForm(emrId, visitId) {
    const medications = DB.get('medications');
    const existing = DB.emrPrescriptions(emrId)[0];

    App.modal({
      title: 'E-Prescription',
      size: 'modal-lg',
      body: `
        <div id="rx-items-list">
          ${(existing?.medications || []).map((m,i) => this._rxItemHTML(i, m, medications)).join('')}
        </div>
        <div id="rx-empty" class="text-center text-muted-color p-4" style="${(existing?.medications||[]).length?'display:none':''}">
          <div style="font-size:13px">Belum ada obat. Tambahkan di bawah.</div>
        </div>
        <button class="btn btn-outline-primary w-full mt-2" onclick="Modules.EMR._addRxItem()">
          ${App.icon('plus',14)} Tambah Obat
        </button>
        <div class="form-group mt-4">
          <label class="form-label">Catatan Apoteker</label>
          <textarea class="form-control" id="rxNotes" rows="2" placeholder="Catatan tambahan untuk apoteker...">${existing?.notes||''}</textarea>
        </div>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-primary" onclick="Modules.EMR.saveRx('${emrId}','${visitId}','${existing?.id||''}')">
          ${App.icon('send',14)} Kirim ke Farmasi
        </button>
      `
    });

    // Add first row if empty
    if (!existing?.medications?.length) {
      setTimeout(() => this._addRxItem(), 100);
    }
  },

  _rxItemHTML(idx, item, medications) {
    return `
      <div class="rx-item" id="rx-row-${idx}" style="display:block;padding:12px;margin-bottom:8px">
        <div class="flex justify-between items-center mb-2">
          <div class="font-semibold" style="font-size:12px;color:var(--text-muted)">OBAT ${idx+1}</div>
          <button class="btn btn-icon-sm btn-ghost" style="color:var(--danger)" onclick="document.getElementById('rx-row-${idx}').remove()">${App.icon('x',12)}</button>
        </div>
        <div class="form-grid" style="gap:10px">
          <div class="form-group" style="margin:0;grid-column:1/-1">
            <select class="form-control rx-med-select" style="font-size:12px" data-idx="${idx}" onchange="Modules.EMR._fillMed(this,${idx})">
              <option value="">Pilih obat...</option>
              ${medications.map(m=>`<option value="${m.id}" data-price="${m.price}" data-unit="${m.unit}" ${item?.medicationId===m.id?'selected':''}>${m.name} (Stok: ${m.stock} ${m.unit})</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Dosis</label>
            <input class="form-control rx-dose" style="font-size:12px" data-idx="${idx}" value="${item?.dose||''}" placeholder="mis. 500mg" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Jumlah</label>
            <input type="number" class="form-control rx-qty" style="font-size:12px" data-idx="${idx}" value="${item?.qty||''}" placeholder="10" min="1" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Frekuensi</label>
            <select class="form-control rx-freq" style="font-size:12px" data-idx="${idx}">
              ${['1x sehari','2x sehari','3x sehari','4x sehari','Jika perlu (prn)','Setiap 8 jam','Setiap 12 jam'].map(f=>`<option ${item?.frequency===f?'selected':''}>${f}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0;grid-column:1/-1">
            <label class="form-label">Keterangan</label>
            <input class="form-control rx-notes" style="font-size:12px" data-idx="${idx}" value="${item?.notes||''}" placeholder="Sebelum/sesudah makan, dll." />
          </div>
        </div>
      </div>`;
  },

  _rxCounter: 0,
  _addRxItem() {
    const list = document.getElementById('rx-items-list');
    const empty = document.getElementById('rx-empty');
    if (empty) empty.style.display = 'none';
    const idx = this._rxCounter++;
    const div = document.createElement('div');
    div.innerHTML = this._rxItemHTML(idx, {}, DB.get('medications'));
    list.appendChild(div.firstElementChild);
  },

  _fillMed(select, idx) { /* auto-fill unit when med selected */ },

  saveRx(emrId, visitId, existingId) {
    const rows = document.querySelectorAll('[id^="rx-row-"]');
    const meds = [];
    rows.forEach(row => {
      const idx = row.id.replace('rx-row-', '');
      const medSel = row.querySelector('.rx-med-select');
      const medId = medSel?.value;
      if (!medId) return;
      const medName = medSel.options[medSel.selectedIndex]?.text?.split(' (')[0];
      const qty = parseInt(row.querySelector('.rx-qty')?.value || 0);
      const unit = DB.getOne('medications', medId)?.unit || '';
      meds.push({
        medicationId: medId,
        name: medName,
        qty,
        unit,
        dose: row.querySelector('.rx-dose')?.value || '',
        frequency: row.querySelector('.rx-freq')?.value || '',
        notes: row.querySelector('.rx-notes')?.value || '',
      });
    });

    if (!meds.length) { App.toast('Tambahkan minimal satu obat', 'warning'); return; }

    const rxData = {
      emrId, visitId,
      medications: meds,
      status: 'menunggu',
      notes: document.getElementById('rxNotes')?.value || '',
      createdBy: App.user.id,
    };

    if (existingId) {
      DB.update('prescriptions', existingId, rxData);
      App.toast('Resep berhasil diperbarui dan dikirim ke farmasi', 'success');
    } else {
      DB.insert('prescriptions', { id: 'RX' + Date.now().toString().slice(-6), ...rxData });
      App.toast('Resep berhasil dikirim ke farmasi', 'success');
    }
    App.closeModal();
    this.render(document.getElementById('content-area'));
  },

  showDetail(emrId) {
    const emr = DB.getOne('emr', emrId);
    if (!emr) return;
    const visit = DB.getOne('visits', emr.visitId);
    const pat = visit ? DB.getOne('patients', visit.patientId) : null;
    const doc = visit ? DB.getOne('doctors', visit.doctorId) : null;
    const prescriptions = DB.emrPrescriptions(emrId);
    const labOrders = DB.visitLabOrders(emr.visitId);
    const vs = emr.vitalSigns || {};

    App.modal({
      title: 'Detail Rekam Medis',
      subtitle: `${pat?.name||''} — ${App.fmt.dateShort(visit?.date)}`,
      size: 'modal-xl',
      body: `
        <!-- Patient Info Bar -->
        <div class="flex gap-3 items-center p-3 mb-4" style="background:#f8fafc;border-radius:var(--radius-sm);border:1px solid var(--border)">
          <div class="avatar avatar-${App.avatarColor(pat?.name||'')}">${App.fmt.initials(pat?.name||'?')}</div>
          <div class="flex-1">
            <div class="font-bold" style="font-size:14px">${pat?.name||'—'}</div>
            <div style="font-size:11.5px;color:var(--text-muted)">${pat?.id} · ${App.fmt.age(pat?.birthDate)} · ${App.fmt.genderLabel(pat?.gender)} · ${doc?.name?.split(',')[0]||''}</div>
          </div>
          <div class="flex gap-2">
            ${emr.allergies ? `<span class="badge badge-danger">⚠ Alergi: ${emr.allergies}</span>` : ''}
            ${App.statusBadge(visit?.status)}
          </div>
        </div>

        <!-- Vital Signs -->
        <div class="mb-4">
          <div class="font-semibold mb-2" style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.06em">Tanda Vital</div>
          <div class="vitals-grid">
            <div class="vital-card"><div class="vital-value">${vs.sistol||'—'}/${vs.diastol||'—'}</div><div class="vital-unit">mmHg</div><div class="vital-label">Tekanan Darah</div></div>
            <div class="vital-card"><div class="vital-value">${vs.nadi||'—'}</div><div class="vital-unit">x/mnt</div><div class="vital-label">Nadi</div></div>
            <div class="vital-card"><div class="vital-value">${vs.suhu||'—'}</div><div class="vital-unit">°C</div><div class="vital-label">Suhu</div></div>
            <div class="vital-card"><div class="vital-value">${vs.rr||'—'}</div><div class="vital-unit">x/mnt</div><div class="vital-label">Frekuensi Napas</div></div>
            <div class="vital-card"><div class="vital-value">${vs.spo2||'—'}</div><div class="vital-unit">%</div><div class="vital-label">SpO2</div></div>
            <div class="vital-card"><div class="vital-value">${vs.bb||'—'} kg</div><div class="vital-unit">${vs.tb||'—'} cm</div><div class="vital-label">BB / TB</div></div>
          </div>
        </div>

        <!-- SOAP -->
        <div class="mb-4">
          <div class="font-semibold mb-2" style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.06em">Catatan SOAP</div>
          ${[
            {label:'S — Subjective', value: emr.subjective, color:'primary'},
            {label:'O — Objective', value: emr.objective, color:'info'},
            {label:'A — Assessment', value: emr.assessment, color:'warning'},
            {label:'P — Plan', value: emr.plan, color:'success'},
          ].map(s => `
            <div style="margin-bottom:10px;padding:12px;background:#fafbfc;border:1px solid var(--border);border-left:3px solid var(--${s.color});border-radius:var(--radius-xs)">
              <div style="font-size:11.5px;font-weight:700;color:var(--${s.color});margin-bottom:4px">${s.label}</div>
              <div style="font-size:13px;color:var(--text-primary);line-height:1.6">${s.value||'—'}</div>
            </div>`
          ).join('')}
        </div>

        <!-- Diagnosis -->
        <div class="grid-2 mb-4" style="gap:10px">
          <div style="padding:12px;background:#f8fafc;border-radius:var(--radius-sm);border:1px solid var(--border)">
            <div style="font-size:11px;font-weight:700;color:var(--text-muted);text-transform:uppercase;margin-bottom:4px">Diagnosis Utama</div>
            <div style="font-size:13px;font-weight:600">${emr.diagnosis||'—'}</div>
          </div>
          <div style="padding:12px;background:#f8fafc;border-radius:var(--radius-sm);border:1px solid var(--border)">
            <div style="font-size:11px;font-weight:700;color:var(--text-muted);text-transform:uppercase;margin-bottom:4px">Diagnosis Sekunder</div>
            <div style="font-size:13px">${emr.secondaryDiagnosis||'—'}</div>
          </div>
        </div>

        <!-- Prescriptions -->
        ${prescriptions.length > 0 ? `
        <div class="mb-4">
          <div class="font-semibold mb-2" style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.06em">
            ${App.icon('pill',13,'','vertical-align:middle')} Resep (${prescriptions.length})
          </div>
          ${prescriptions.map(rx => `
            <div style="background:#f8fafc;border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;margin-bottom:8px">
              <div class="flex justify-between items-center mb-2">
                <span class="font-semibold" style="font-size:12px">Resep #${rx.id}</span>
                ${App.statusBadge(rx.status)}
              </div>
              ${rx.medications.map(m=>`
                <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px">
                  <div class="font-semibold">${m.name}</div>
                  <div style="color:var(--text-secondary)">${m.qty} ${m.unit} · ${m.dose} · ${m.frequency}</div>
                </div>`).join('')}
              ${rx.notes ? `<div style="font-size:12px;color:var(--info);margin-top:6px">📝 ${rx.notes}</div>` : ''}
            </div>`).join('')}
        </div>` : ''}

        <!-- Lab -->
        ${labOrders.length > 0 ? `
        <div>
          <div class="font-semibold mb-2" style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.06em">
            ${App.icon('microscope',13,'','vertical-align:middle')} Hasil Lab (${labOrders.length})
          </div>
          ${labOrders.map(lo => `
            <div style="background:#f8fafc;border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;margin-bottom:8px">
              <div class="flex justify-between mb-2">
                <span class="font-semibold" style="font-size:12px">${lo.tests.map(t=>t.name).join(', ')}</span>
                ${App.statusBadge(lo.status)}
              </div>
              ${lo.results?.length ? lo.results.map(r=>`
                <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--border);font-size:12px">
                  <span>${r.test}</span>
                  <span style="font-weight:600;color:${r.flag==='H'?'var(--danger)':r.flag==='L'?'var(--info)':'var(--success)'}">${r.value} ${r.unit} (${r.normalRange})</span>
                </div>`).join('') : '<div style="font-size:12px;color:var(--text-muted)">Hasil belum tersedia</div>'}
            </div>`).join('')}
        </div>` : ''}
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Tutup</button>
        ${App.user.role !== 'kasir' && App.user.role !== 'lab' ? `
        <button class="btn btn-outline-primary" onclick="App.closeModal();Modules.EMR.showPrescriptionForm('${emrId}','${emr.visitId}')">
          ${App.icon('pill',13)} Tulis Resep
        </button>
        <button class="btn btn-primary" onclick="App.closeModal();Modules.EMR.showForm('${emr.visitId}')">
          ${App.icon('edit',13)} Edit EMR
        </button>` : ''}
      `
    });
  }
};
