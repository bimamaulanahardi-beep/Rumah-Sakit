/**
 * SIMRS — Users Module (Manajemen Pengguna)
 */
Modules.Users = {
  render(container) {
    const users = DB.get('users');
    const roles = {
      admin: { label: 'Administrator', color: 'blue', icon: 'shield-check' },
      dokter: { label: 'Dokter', color: 'green', icon: 'activity' },
      apoteker: { label: 'Apoteker', color: 'purple', icon: 'pill' },
      kasir: { label: 'Kasir', color: 'amber', icon: 'credit-card' },
      lab: { label: 'Analis Lab', color: 'teal', icon: 'microscope' },
    };

    container.innerHTML = `
      <div class="page-header fade-up">
        <div>
          <h2>Manajemen Pengguna</h2>
          <p>${users.length} pengguna terdaftar di sistem</p>
        </div>
        ${App.user.role === 'admin' ? `
        <div class="page-header-actions">
          <button class="btn btn-primary" onclick="Modules.Users.showForm(null)">
            ${App.icon('user-plus',14)} Tambah Pengguna
          </button>
        </div>` : ''}
      </div>

      <!-- Role Stats -->
      <div class="stats-grid stagger mb-4">
        ${Object.entries(roles).map(([role, info]) => `
          <div class="stat-card fade-up">
            <div class="stat-icon" style="background:var(--${info.color}-subtle)">${App.icon(info.icon,24,'','color:var(--'+info.color+')')}</div>
            <div class="stat-body">
              <h3>${users.filter(u=>u.role===role).length}</h3>
              <p>${info.label}</p>
            </div>
          </div>`).join('')}
      </div>

      <div class="card fade-up">
        <div class="card-header">
          <span class="card-title">${App.icon('users',16)} Daftar Pengguna</span>
        </div>
        <div class="table-container" style="border:none;border-radius:0">
          <table class="table">
            <thead>
              <tr><th>Pengguna</th><th>Username</th><th>Role</th><th>Email</th><th>Telepon</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
              ${users.map(u => {
                const roleInfo = roles[u.role] || { label: u.role, color: 'neutral', icon: 'user' };
                return `
                  <tr>
                    <td>
                      <div class="flex items-center gap-2">
                        <div class="avatar avatar-sm avatar-${roleInfo.color}">${App.fmt.initials(u.name)}</div>
                        <div>
                          <div class="font-semibold" style="font-size:13px">${u.name}</div>
                          <div style="font-size:11px;color:var(--text-muted)">${u.id}</div>
                        </div>
                      </div>
                    </td>
                    <td><code style="font-size:12px;background:#f1f5f9;padding:2px 8px;border-radius:4px">${u.username}</code></td>
                    <td>
                      <span class="badge badge-${roleInfo.color} badge-status">${roleInfo.label}</span>
                    </td>
                    <td style="font-size:12px">${u.email||'—'}</td>
                    <td style="font-size:12px">${u.phone||'—'}</td>
                    <td>
                      <span class="badge ${u.isActive?'badge-success':'badge-neutral'}">${u.isActive?'Aktif':'Nonaktif'}</span>
                    </td>
                    <td>
                      ${App.user.role === 'admin' ? `
                      <div class="flex gap-1">
                        <button class="btn btn-icon-sm btn-ghost" onclick="Modules.Users.showForm('${u.id}')" title="Edit">${App.icon('edit',13)}</button>
                        <button class="btn btn-icon-sm btn-ghost" onclick="Modules.Users.showResetPassword('${u.id}')" title="Reset Password">${App.icon('key',13)}</button>
                        ${u.id !== App.user.id ? `
                        <button class="btn btn-icon-sm btn-ghost" onclick="Modules.Users.toggleActive('${u.id}','${u.isActive}')" title="${u.isActive?'Nonaktifkan':'Aktifkan'}">
                          ${App.icon(u.isActive?'lock':'unlock',13)}
                        </button>` : ''}
                      </div>` : '—'}
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Current User Profile -->
      <div class="card mt-4 fade-up">
        <div class="card-header"><span class="card-title">${App.icon('user',16)} Profil Saya</span></div>
        <div class="card-body">
          <div class="flex items-center gap-4 mb-4">
            <div class="avatar avatar-xl avatar-${roles[App.user.role]?.color||'blue'}">${App.fmt.initials(App.user.name)}</div>
            <div>
              <div style="font-size:18px;font-weight:700">${App.user.name}</div>
              <div style="font-size:13px;color:var(--text-muted)">@${App.user.username} · ${roles[App.user.role]?.label}</div>
            </div>
          </div>
          <div class="grid-2" style="gap:0">
            <div>
              <div class="info-row"><div class="info-label">Username</div><div class="info-value">${App.user.username}</div></div>
              <div class="info-row"><div class="info-label">Email</div><div class="info-value">${App.user.email||'—'}</div></div>
            </div>
            <div>
              <div class="info-row"><div class="info-label">Telepon</div><div class="info-value">${App.user.phone||'—'}</div></div>
              <div class="info-row"><div class="info-label">Role</div><div class="info-value">${roles[App.user.role]?.label}</div></div>
            </div>
          </div>
          <button class="btn btn-outline-primary btn-sm mt-2" onclick="Modules.Users.showForm('${App.user.id}')">
            ${App.icon('edit',13)} Edit Profil
          </button>
        </div>
      </div>
    `;
  },

  showForm(id) {
    const u = id ? DB.getOne('users', id) : null;
    const isOwnProfile = id === App.user.id;
    const canAssignRole = App.user.role === 'admin' && !isOwnProfile;
    const isNew = !u;

    App.modal({
      title: isNew ? 'Tambah Pengguna' : (isOwnProfile ? 'Edit Profil Saya' : 'Edit Pengguna'),
      body: `
        <form id="userForm" onsubmit="Modules.Users.save(event,'${id||''}')">
          <div class="form-group">
            <label class="form-label">Nama Lengkap <span class="required">*</span></label>
            <input class="form-control" name="name" required value="${u?.name||''}" placeholder="Nama lengkap" />
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">Username <span class="required">*</span></label>
              <input class="form-control" name="username" required value="${u?.username||''}" placeholder="username" />
            </div>
            <div class="form-group">
              <label class="form-label">Role <span class="required">*</span></label>
              <select class="form-control" name="role" required ${!canAssignRole && !isNew?'disabled':''}>
                ${['admin','dokter','apoteker','kasir','lab'].map(r=>`<option value="${r}" ${u?.role===r?'selected':''}>${{admin:'Administrator',dokter:'Dokter',apoteker:'Apoteker',kasir:'Kasir',lab:'Analis Lab'}[r]}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" name="email" value="${u?.email||''}" placeholder="email@rsrakyat.id" />
            </div>
            <div class="form-group">
              <label class="form-label">No. Telepon</label>
              <input class="form-control" name="phone" value="${u?.phone||''}" placeholder="08xxxxxxxxxx" />
            </div>
          </div>
          ${isNew ? `
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">Password <span class="required">*</span></label>
              <input type="password" class="form-control" name="password" required placeholder="Minimal 6 karakter" minlength="6" />
            </div>
            <div class="form-group">
              <label class="form-label">Konfirmasi Password <span class="required">*</span></label>
              <input type="password" class="form-control" name="password2" required placeholder="Ulangi password" />
            </div>
          </div>` : ''}
          ${App.user.role === 'admin' && !isOwnProfile ? `
          <div class="form-check mt-2">
            <input type="checkbox" name="isActive" id="isActiveUser" ${!u||u.isActive?'checked':''} />
            <label class="form-check-label" for="isActiveUser">Akun aktif</label>
          </div>` : ''}
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-primary" onclick="document.getElementById('userForm').requestSubmit()">
          ${App.icon('save',14)} ${isNew?'Tambah Pengguna':'Simpan'}
        </button>
      `
    });
  },

  save(e, id) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));

    if (!id && data.password !== data.password2) {
      App.toast('Password tidak cocok', 'error');
      return;
    }
    if (!id && DB.get('users').some(u => u.username === data.username)) {
      App.toast('Username sudah digunakan', 'error');
      return;
    }

    const isAdmin = App.user.role === 'admin';
    const isOwn = id === App.user.id;

    if (id) {
      const updates = { name: data.name, username: data.username, email: data.email, phone: data.phone };
      if (isAdmin && !isOwn) {
        updates.role = data.role;
        updates.isActive = !!e.target.isActive?.checked;
      }
      DB.update('users', id, updates);
      // Update session if own profile
      if (isOwn) {
        const updated = DB.getOne('users', id);
        sessionStorage.setItem('simrs_user', JSON.stringify(updated));
        App.user = updated;
        App.renderSidebar();
        App.renderTopbar();
      }
      App.toast('Data pengguna berhasil diperbarui', 'success');
    } else {
      const newId = 'USR' + String(DB.count('users') + 1).padStart(3, '0');
      DB.insert('users', {
        id: newId,
        username: data.username,
        password: data.password,
        name: data.name,
        role: data.role,
        email: data.email,
        phone: data.phone,
        isActive: true,
      });
      App.toast(`Pengguna ${data.name} berhasil ditambahkan`, 'success');
    }

    App.closeModal();
    this.render(document.getElementById('content-area'));
  },

  showResetPassword(userId) {
    App.modal({
      title: 'Reset Password',
      subtitle: `User: ${DB.getOne('users',userId)?.name||userId}`,
      size: 'modal-sm',
      body: `
        <form id="resetPwForm" onsubmit="Modules.Users.resetPassword(event,'${userId}')">
          <div class="form-group">
            <label class="form-label">Password Baru <span class="required">*</span></label>
            <input type="password" class="form-control" name="newPassword" required placeholder="Minimal 6 karakter" minlength="6" />
          </div>
          <div class="form-group">
            <label class="form-label">Konfirmasi Password <span class="required">*</span></label>
            <input type="password" class="form-control" name="confirmPassword" required placeholder="Ulangi password baru" />
          </div>
        </form>
      `,
      footer: `
        <button class="btn btn-secondary" onclick="App.closeModal()">Batal</button>
        <button class="btn btn-warning" onclick="document.getElementById('resetPwForm').requestSubmit()">
          ${App.icon('key',14)} Reset Password
        </button>
      `
    });
  },

  resetPassword(e, userId) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    if (data.newPassword !== data.confirmPassword) {
      App.toast('Password tidak cocok', 'error');
      return;
    }
    DB.update('users', userId, { password: data.newPassword });
    App.toast('Password berhasil direset', 'success');
    App.closeModal();
  },

  toggleActive(userId, currentStatus) {
    const newStatus = currentStatus === 'true' || currentStatus === true ? false : true;
    const user = DB.getOne('users', userId);
    App.confirm({
      title: newStatus ? 'Aktifkan Pengguna' : 'Nonaktifkan Pengguna',
      message: `Yakin ingin ${newStatus?'mengaktifkan':'menonaktifkan'} akun <strong>${user?.name}</strong>?`,
      confirmLabel: newStatus ? 'Aktifkan' : 'Nonaktifkan',
      confirmClass: newStatus ? 'btn-success' : 'btn-warning',
      onConfirm: () => {
        DB.update('users', userId, { isActive: newStatus });
        App.toast(`Akun ${newStatus?'diaktifkan':'dinonaktifkan'}`, newStatus?'success':'warning');
        Modules.Users.render(document.getElementById('content-area'));
      }
    });
  }
};
